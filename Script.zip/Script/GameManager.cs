using System;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    public static bool isEnd
    {
        get
        {
            return IsEnd;
        }
    }
    private static bool IsEnd = false;

    [SerializeField] private Building Core;
    [SerializeField] private UIText WinTips;

    private void Awake()
    {
        float randomSeed = -100000 + UnityEngine.Random.value * 200000;
        ResourceGenerator.seed = Mathf.FloorToInt(randomSeed);
    }
    private void Update()
    {
        if(Core == null || Core.isDead)
        {
            WinTips.gameObject.SetActive(true);
            WinTips.key = "Lose";
            BuildPannel.main.ClosePannel();
            BuildingPannel.main.Choose(null);
            IsEnd = true;
        }
        if(EnemyGenerator.isAllWaveEnd && Enemy.EnemyList.Count == 0)
        {
            WinTips.gameObject.SetActive(true);
            WinTips.key = "Win";
            BuildPannel.main.ClosePannel();
            BuildingPannel.main.Choose(null);
            IsEnd = true;
        }
    }
}
