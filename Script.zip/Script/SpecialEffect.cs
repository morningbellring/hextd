using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpecialEffect : MonoBehaviour
{
    public void Destory()
    {
        GameObject.Destroy(this.gameObject);
    }
}
