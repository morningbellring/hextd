using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyTestButton : MonoBehaviour
{
    private bool Generating = false;
    public void Click()
    {
        Generating = !Generating;
        EnemyGenerator.generateAmount = Generating ? 120 : 0;
    }
}
