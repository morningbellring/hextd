using JetBrains.Annotations;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TimePause : MonoBehaviour
{
    public Image PauseImage;
    public Sprite PauseSprite;
    public Sprite ResumeSprite;
    private void Start()
    {
        KeyListener.GetEvent("Pause").DownEvent += PauseOrResume;
    }
    public void PauseOrResume()
    {
        if (GameManager.isEnd) return;
        if (Time.timeScale == 0)
        {
            Time.timeScale = 1;
            PauseImage.sprite = PauseSprite;
            PauseImage.color = new Color(1, 1, 1, 1);
        }
        else
        {
            Time.timeScale = 0;
            PauseImage.sprite = ResumeSprite;
            PauseImage.color = new Color(1, 1, 1, 1);
        }
    }
    private void Update()
    {
        if(GameManager.isEnd && Time.timeScale == 1)
        {
            Time.timeScale = 0;
        }
        if(PauseImage.color.a > 0.3f)
        {
            PauseImage.color = new Color(1, 1, 1, PauseImage.color.a - Time.deltaTime);
            if(PauseImage.color.a < 0.3f)
            {
                PauseImage.color = new Color(1, 1, 1, 0.3f);
            }
        }
    }
}
