using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BuildPannelChoice : MonoBehaviour
{
    public List<Building> Buildings = new List<Building>();
    public void Click()
    {
        BuildPannel.main.OpenPannel(Buildings.ToArray());
    }
}
