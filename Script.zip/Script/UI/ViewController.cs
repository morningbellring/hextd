using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ViewController : MonoBehaviour
{
    private float FieldOfView = 80;
    private void Start()
    {
        KeyListener.GetEvent("IncreaseView").DownEvent += IncreaseView;
        KeyListener.GetEvent("DecreaseView").DownEvent += DecreaseView;
    }
    private void IncreaseView()
    {
        FieldOfView += 5;
        FieldOfView = FieldOfView > 110 ? 110 : FieldOfView;
    }
    private void DecreaseView()
    {
        FieldOfView -= 5;
        FieldOfView = FieldOfView < 50 ? 50 : FieldOfView;
    }
    private void Update()
    {
        if(Camera.main.fieldOfView != FieldOfView)
        {
            if (Mathf.Abs(Camera.main.fieldOfView - FieldOfView) <= 0.05f) Camera.main.fieldOfView = FieldOfView;
            else Camera.main.fieldOfView += (FieldOfView - Camera.main.fieldOfView) / 8 * Time.unscaledDeltaTime / Time.fixedDeltaTime;
        }
    }
}
