using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class CostItem : MonoBehaviour
{
    public string resourceName
    {
        set
        {
            Icon.sprite = Resources.Load<Sprite>("ResourceIcon/" + value);
            
        }
    }
    public float resourceCost
    {
        set
        {
            Text.text = value.ToString();
        }
    }

    [SerializeField] private TextMeshProUGUI Text;
    [SerializeField] private Image Icon;
}
