using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using static UnityEngine.Rendering.DebugUI;

public class BuildPannel : MonoBehaviour
{
    public static BuildPannel main
    {
        get { return Main; }
    }
    public static bool inBuildMode
    {
        get
        {
            return Main.InBuildMode;
        }
    }
    private static BuildPannel Main;

    [SerializeField] private GameObject RowPrefab;
    [SerializeField] private GameObject ButtonPrefab;
    [SerializeField] private GameObject CostPrefab;

    [SerializeField] private RectTransform PannelObject;
    [SerializeField] private RectTransform ButtonPannel;
    [SerializeField] private RectTransform CostPannel;
    [SerializeField] private RectTransform PreviewObject;
    [SerializeField] private Image Preview;
    [SerializeField] private GameObject ButtonTips;
    [SerializeField] private UIText ButtonTitle;
    [SerializeField] private UIText ButtonContent;


    private List<GameObject> ButtonUI = new List<GameObject>();
    private List<GameObject> CostUI = new List<GameObject>();

    private float PannelX = -200;
    private float PreviewY = -75;

    private bool InBuildMode = false;
    private bool IsBuildable = false;
    private Vector2Int LastBuildingPosition;
    private GameObject BuildingPoint;
    private Building ChosenBuilding;
    private Building BuildingInBuild;

    public void TryBuild(Building building)
    {
        if (building == null) return;
        BuildingPannel.main.Choose(null);
        ClosePannel();
        ChosenBuilding = building;
        InBuildMode = true;
        IsBuildable = false;
        PreviewY = 75;

        Preview.sprite = building.Preview;
        Preview.SetNativeSize();

        RectTransform rect = Preview.transform as RectTransform;
        Vector2 size = rect.sizeDelta;
        if (size.x > 115)
        {
            size.y *= 115 / size.x;
            size.x = 115;
        }
        if (size.y > 115)
        {
            size.x *= 115 / size.y;
            size.y = 115;
        }
        rect.sizeDelta = size;

        GameObject newBuilding = GameObject.Instantiate(building.gameObject);
        newBuilding.transform.SetParent(BuildingPoint.transform);
        newBuilding.transform.localScale = Vector3.one;

        BuildingInBuild = newBuilding.GetComponent<Building>();
        TileMap.main.ShowPowerMap();
        LastBuildingPosition = Vector2Int.one * 99999;
        BuildModeUpdate();
    }
    public void ExitBuild()
    {
        if (InBuildMode)
        {
            TileMap.main.HidePowerMap();
            if (BuildingInBuild != null)
            {
                BuildingInBuild.HidePreview();
                GameObject.Destroy(BuildingInBuild.gameObject);
            }
            InBuildMode = false;
            OpenPannel();
        }
    }
    public void OpenPannel(Building[] buttons)
    {
        if (GameManager.isEnd) return;
        ExitBuild();
        ClearUI();
        PannelX = 235;
        PreviewY = -75;

        GameObject rowObject = null;
        int rowCount = 0;
        foreach(Building b in buttons)
        {
            if(rowObject == null || rowCount >= 3)
            {
                rowObject = GameObject.Instantiate(RowPrefab);
                rowObject.transform.SetParent(ButtonPannel);
                rowObject.transform.localPosition = Vector3.zero;
                rowObject.transform.localScale = Vector3.one;

                rowCount = 0;
                ButtonUI.Add(rowObject);
            }
            AddButton(b, rowObject.transform);
            rowCount++;
        }
    }
    public void CloseButtonTips()
    {
        ButtonTips.SetActive(false);
        ClearCostUI();
    }
    public void ClosePannel()
    {
        CloseButtonTips();
        PannelX = -200;
    }
    public void OpenButtonTips(Building building)
    {
        if (InBuildMode) return;

        ButtonTips.SetActive(true);

        ButtonTitle.key = building.Name;
        ButtonContent.key = building.Name;

        for(int i = 0; i < building.ResourceCost.Length; i++)
        {
            GameObject newItem = GameObject.Instantiate(CostPrefab);
            newItem.transform.SetParent(CostPannel);
            newItem.transform.localScale = Vector3.one;
            newItem.transform.localPosition = Vector3.zero;

            CostItem costItem = newItem.GetComponent<CostItem>();
            costItem.resourceCost = building.ResourceCost[i];
            costItem.resourceName = building.ResourceName[i];
            CostUI.Add(newItem);
        }
    }
    private void AddButton(Building building, Transform row) 
    {
        GameObject buttonObject = GameObject.Instantiate(ButtonPrefab);
        buttonObject.transform.SetParent(row);
        buttonObject.transform.localPosition = Vector3.zero;
        buttonObject.transform.localScale = Vector3.one;

        BuildButton button = buttonObject.GetComponent<BuildButton>();
        button.building = building;
    }
    private void Awake()
    {
        BuildingPoint = GameObject.Find("Buildings");
        ButtonTips.SetActive(false);
        PannelObject.anchoredPosition = new Vector3(PannelX, 310, 0);
        Main = this;
    }
    private void Start()
    {
        KeyListener.GetEvent("Point").DownEvent += () =>
        {
            if (!Mouse.IsPointerOverUIElement())
            {
                ClosePannel();
            }
            if (InBuildMode)
            {
                BuildComfirm();
            }
        };
        KeyListener.GetEvent("ExitPreview").DownEvent += ExitBuild;
    }
    private void Update()
    {
        float TimeRate = Time.unscaledDeltaTime / Time.fixedDeltaTime;
        Vector3 nowPos = PannelObject.anchoredPosition;
        if(Mathf.Abs(nowPos.x - PannelX) > 1f)
        {
            nowPos.x += (PannelX - nowPos.x) / 5 * TimeRate;
        }
        else
        {
            nowPos.x = PannelX;
        }
        PannelObject.anchoredPosition = nowPos;

        nowPos = PreviewObject.anchoredPosition;
        if (Mathf.Abs(nowPos.y - PreviewY) > 1f)
        {
            nowPos.y += (PreviewY - nowPos.y) / 5 * TimeRate;
        }
        else
        {
            nowPos.y = PreviewY;
        }
        PreviewObject.anchoredPosition = nowPos;

        BuildModeUpdate();
    }
    private void BuildComfirm()
    {
        if (InBuildMode && HexagonalMap.IsBuildable(BuildingInBuild.occupyArea))
        {
            BuildingInBuild.HidePreview();
            BuildingInBuild.StartBuild();
            BuildingInBuild = null;
            InBuildMode = false;
            TryBuild(ChosenBuilding);
        }
    }
    private void BuildModeUpdate()
    {
        if (InBuildMode || BuildingInBuild != null)
        {
            Vector2Int mousePos = TileMap.main.mousePos;
            BuildingInBuild.transform.position = TileMap.main.GetWorldPos(mousePos);
            BuildingInBuild.BuildingPosition = mousePos;

            IsBuildable = HexagonalMap.IsBuildable(BuildingInBuild.occupyArea);

            BuildingInBuild.vision.color = IsBuildable ? Color.white : Color.red;

            if(mousePos != LastBuildingPosition)
            {
                LastBuildingPosition = mousePos;
                BuildingInBuild.ShowPreview();
            }
        }
    }
    private void OpenPannel()
    {
        PannelX = 235;
        PreviewY = -75;
    }
    private void ClearCostUI()
    {
        foreach (GameObject g in CostUI)
        {
            GameObject.Destroy(g);
        }
        CostUI.Clear();
    }
    private void ClearUI()
    {
        foreach (GameObject g in CostUI)
        {
            GameObject.Destroy(g);
        }
        CostUI.Clear();
        foreach (GameObject g in ButtonUI)
        {
            GameObject.Destroy(g);
        }
        ButtonUI.Clear();
    }
}
