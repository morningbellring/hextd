using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class BuildingSelecter : MonoBehaviour
{
    private LayerMask Mask;
    
    private void Start()
    {
        KeyListener.GetEvent("Point").DownEvent += Select;
        Mask = LayerMask.GetMask(new string[] { "Pointer" });
    }
    private void Select()
    {
        if (Mouse.IsPointerOverUIElement()) return;
        Vector3 screenPoint = new Vector3(Input.mousePosition.x, Input.mousePosition.y, -Camera.main.transform.position.z);
        Vector2 wPoint = Camera.main.ScreenToWorldPoint(screenPoint);
        Collider2D collider = Physics2D.OverlapPoint(wPoint, Mask);
        if(collider != null && collider.TryGetComponent<BuildingCollider>(out BuildingCollider bc))
        {
            BuildingPannel.main.Choose(bc.Building);
        }
        else
        {
            BuildingPannel.main.Choose(null);
        }
    }
}