using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class PannelButton : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    public PannelData.ButtonCD cdEvent
    {
        set
        {
            CDEvent = value;
            Fill.fillAmount = CDEvent(BuildingDisplay);
        }
    }
    public string icon
    {
        set
        {
            Icon.sprite = Resources.Load<Sprite>("ButtonIcon/" + value);
        }
    }

    public Image Fill;
    public Image Icon;

    [HideInInspector] public Building BuildingDisplay;
    [HideInInspector] public string Title;
    [HideInInspector] public string Content;
    public PannelData.ButtonClick ClickEvent;
    private PannelData.ButtonCD CDEvent;
    public void ButtonClick()
    {
        if(CDEvent(BuildingDisplay) == 0)
        {
            ClickEvent(BuildingDisplay);
        }
    }
    public void OnPointerEnter(PointerEventData evt)
    {
        BuildingPannel.main.ShowButtonText(Title, Content);
    }
    public void OnPointerExit(PointerEventData evt)
    {
        BuildingPannel.main.HideButtonText();
    }
    private void FixedUpdate()
    {
        if (BuildingDisplay == null) return;
        Fill.fillAmount = CDEvent(BuildingDisplay);
    }
}
