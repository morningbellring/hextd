using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.TextCore.Text;

public class PannelRemoveButton : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    public Building building
    {
        set
        {
            Building = value;
            this.gameObject.SetActive(Building.isRemovable);
        }
    }
    private bool MouseOn = false;
    private string TextType = "";
    private Building Building;
    public void OnPointerEnter(PointerEventData evt)
    {
        MouseOn = true;
        UpdateTextType();
    }
    public void OnPointerExit(PointerEventData evt)
    {
        MouseOn = false;
        TextType = "";
        BuildingPannel.main.HideButtonText();
    }
    public void Click()
    {
        Building.Remove();
    }
    private void UpdateTextType()
    {
        float progress = Building.buildProgress;
        string newText = "";
        if (progress == 0)
        {
            newText = "RemovePreview";
        }
        else if(progress < 1)
        {
            newText = "RemoveBuild";
        }
        else
        {
            newText = "RemoveComplete";
        }
        if(newText != TextType)
        {
            TextType = newText;
            BuildingPannel.main.ShowButtonText("Remove", TextType);
        }
    }
    private void FixedUpdate()
    {
        if(MouseOn && Building != null)
        {
            UpdateTextType();
        }
    }
}
