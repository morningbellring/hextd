using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class ResourceBar : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI ResourceAmount;
    [SerializeField] private TextMeshProUGUI ResourceIncrease;

    [SerializeField] private Image Fill;
    public string ResourceDisplay;

    private void FixedUpdate()
    {
        int resourceAmount = Mathf.FloorToInt(ResourceManager.GetResource(ResourceDisplay));
        int toplimitAmount = Mathf.FloorToInt(ResourceManager.GetResourceToplimit(ResourceDisplay));
        int increaseAmount = Mathf.FloorToInt(ResourceManager.GetResourceIncreasment(ResourceDisplay));

        ResourceAmount.text = resourceAmount.ToString();
        if (increaseAmount > 0)
        {
            ResourceIncrease.text = "+ " + Mathf.Abs(increaseAmount);
            ResourceIncrease.color = new Color(0.5f, 1, 0.5f);
        }
        else if (increaseAmount < 0)
        {
            ResourceIncrease.text = "- " + Mathf.Abs(increaseAmount);
            ResourceIncrease.color = new Color(1, 0.5f, 0.5f);
        }
        else
        {
            ResourceIncrease.text = "";
        }

        if (toplimitAmount <= 0)
        {
            Fill.fillAmount = 0;
        }
        else
        {
            Fill.fillAmount = (float)resourceAmount / (float)toplimitAmount;
        }
        
    }
}
