using System.Collections;
using System.Collections.Generic;
using UnityEditor.IMGUI.Controls;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class BuildButton : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    public Building building
    {
        set
        {
            Building = value;

            ButtonImage.sprite = value.Preview;
            ButtonImage.SetNativeSize();

            RectTransform rect = ButtonImage.transform as RectTransform;
            Vector2 size = rect.sizeDelta;
            if (size.x > 80)
            {
                size.y *= 80 / size.x;
                size.x = 80;
            }
            if (size.y > 80)
            {
                size.x *= 80 / size.y;
                size.y = 80;
            }
            rect.sizeDelta = size;
        }
    }
    [SerializeField] private Image ButtonImage;
    private Building Building;

    public void OnPointerEnter(PointerEventData data)
    {
        BuildPannel.main.OpenButtonTips(Building);
    }
    public void OnPointerExit(PointerEventData data)
    {
        BuildPannel.main.CloseButtonTips();
    }
    public void Click()
    {
        BuildPannel.main.TryBuild(Building);
    }
    
}
