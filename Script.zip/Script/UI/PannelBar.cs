using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using static PannelData;

public class PannelBar : MonoBehaviour
{
    public Color color
    {
        set
        {
            NowColor = value;
            NowColor.a = ColorAlpha;
            Fill.color = NowColor;
        }
    }
    public string title
    {
        set
        {
            TitleText.key = value;
        }
    }
    public BarContent content
    {
        set
        {
            Content = value;
            ContentText.text = Content(BuildingDisplay);
        }
    }
    public BarProcess process
    {
        set
        {
            Process = value;
            Fill.fillAmount = Process(BuildingDisplay);
        }
    }

    [HideInInspector] public Building BuildingDisplay;

    private PannelData.BarContent Content;
    private PannelData.BarProcess Process;

    [SerializeField] private Image Fill;
    [SerializeField] private UIText TitleText;
    [SerializeField] private TextMeshProUGUI ContentText;

    private Color NowColor = Color.white;
    private float ColorAlpha = 0.5f;

    private void Update()
    {
        if (Process != null)
        {
            float targetFill = Process(BuildingDisplay);
            if (Fill.fillAmount != targetFill)
            {
                Fill.fillAmount = targetFill;
                ColorAlpha = 1;
            }
        }
        if(Content != null)
        {
            ContentText.text = Content(BuildingDisplay);
        }

        if (ColorAlpha > 0.5f)
        {
            ColorAlpha -= Time.unscaledDeltaTime * 5;
        }
        if(ColorAlpha < 0.5f)
        {
            ColorAlpha = 0.5f;
        }
        NowColor.a = ColorAlpha;
        Fill.color = NowColor;
    }
}
