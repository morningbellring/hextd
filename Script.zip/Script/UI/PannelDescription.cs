using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using static PannelData;

public class PannelDescription : MonoBehaviour
{
    public string title
    {
        set
        {
            Title.key = value;
        }
    }
    public PannelData.DescriptionContent content
    {
        set
        {
            ContentEvent = value;
            Content.text = ContentEvent(BuildingDisplay);
        }
    }

    [HideInInspector] public Building BuildingDisplay;

    [SerializeField] private UIText Title;
    [SerializeField] private TextMeshProUGUI Content;

    private PannelData.DescriptionContent ContentEvent;

    private void FixedUpdate()
    {
        if(BuildingDisplay != null)
        {
            Content.text = ContentEvent(BuildingDisplay);
        }
    }
}
