using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Dragger : MonoBehaviour
{
    private Camera WorldCamera;
    private Vector2 LastPosition;

    private void Start()
    {
        WorldCamera = Camera.main;
    }
    private void Update()
    {
        if (KeyListener.isActive("Drag"))
        {
            float sensitivity = (Camera.main.fieldOfView / 80) * 30;

            Vector3 mouseDiff = Vector3.zero;
            Vector2 mousePosition = Input.mousePosition;
            mouseDiff.x = (LastPosition.x - mousePosition.x) / Screen.width * sensitivity;
            mouseDiff.y = (LastPosition.y - mousePosition.y) / Screen.height * (sensitivity * Screen.height / Screen.width);
            WorldCamera.transform.position += mouseDiff;
        }
        LastPosition = Input.mousePosition;
    }
}
