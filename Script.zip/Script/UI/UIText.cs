using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIText : MonoBehaviour
{
    public string file
    {
        set
        {
            if (value == File) return;
            File = value;
            TextUpdate();
        }
    }
    public string key
    {
        set
        {
            if (value == Key) return;
            Key = value;
            TextUpdate();
        }
    }
    public Color color
    {
        set
        {
            if (Text != null) Text.color = value;
            if (TextMesh != null) TextMesh.color = value;
        }
    }
    [SerializeField] private string File;
    [SerializeField] private string Key;

    [SerializeField] private Text Text;
    [SerializeField] private TMPro.TextMeshProUGUI TextMesh;
    public delegate void TextEvent(string value);
    public event TextEvent TextChange;
    private void Start()
    {
        if (Text == null) Text = this.GetComponent<Text>();
        if (TextMesh == null) TextMesh = this.GetComponent<TMPro.TextMeshProUGUI>();
        TextUpdate();
        LanguageReader.ChangeLanguage += TextUpdate;
    }
    private void TextUpdate()
    {
        if (Key == "" || File == "") return;
        string text = LanguageReader.Read(File, Key);
        if (TextChange == null)
        {
            if (Text != null) Text.text = text;
            if (TextMesh != null) TextMesh.text = text;
        }
        else
        {
            TextChange(text);
        }
    }
    private void OnDestroy()
    {
        LanguageReader.ChangeLanguage -= TextUpdate;
    }
}
