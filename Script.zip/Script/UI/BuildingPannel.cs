using System.Collections.Generic;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;

public class BuildingPannel : MonoBehaviour
{
    public static BuildingPannel main { get { return Main; } }
    private static BuildingPannel Main;
    private static Color ChosenBreatheColor = new Color(1.8f, 1.8f, 1.8f);

    private Building ChosenBuilding;

    [SerializeField] private Image Preview;

    [SerializeField] private GameObject BarPrefab;
    [SerializeField] private GameObject DescriptionPrefab;
    [SerializeField] private GameObject ButtonPrefab;
    [SerializeField] private GameObject ButtonRowPrefab;

    [SerializeField] private RectTransform ContentPoint;
    [SerializeField] private UIText BuildingName;
    [SerializeField] private UIText BuildingType;
    [SerializeField] private GameObject ButtonTextPannel;
    [SerializeField] private UIText ButtonTextTitle;
    [SerializeField] private UIText ButtonTextContent;
    [SerializeField] private PannelRemoveButton RemoveButton;

    private float TargetX = 180;

    private RectTransform Rect;

    private List<GameObject> AdditionalUI = new List<GameObject>();
    public void Choose(Building building)
    {
        if (GameManager.isEnd) return;
        if (BuildPannel.inBuildMode) building = null;
        if (ChosenBuilding != null)
        {
            ChosenBuilding.vision.StopBreathe();
            ChosenBuilding.HidePreview();
        }
        else
        {
            TargetX = -180;
        }

        if (building != null)
        {
            ChosenBuilding = building.pannelData == null ? null : building;
        }
        else ChosenBuilding = null;
        
        if (ChosenBuilding != null)
        {
            ChosenBuilding.vision.StartBreathe(ChosenBreatheColor);
            ChosenBuilding.ShowPreview();
            Repaint();
        }
        else
        {
            TargetX = 180;
        }
    }
    public void Repaint()
    {
        if (ChosenBuilding == null) return;
        foreach(GameObject g in AdditionalUI)
        {
            GameObject.Destroy(g);
        }
        AdditionalUI.Clear();
        HideButtonText();

        PannelData data = ChosenBuilding.pannelData;
        data.Pannel = this;

        // �󶨲����ť
        RemoveButton.building = ChosenBuilding;

        // ����Ԥ��ͼ��С;
        Preview.sprite = data.Preview;
        Preview.SetNativeSize();

        RectTransform rect = Preview.transform as RectTransform;
        Vector2 size = rect.sizeDelta;
        if (size.x > 100)
        {
            size.y *= 100 / size.x;
            size.x = 100;
        }
        if (size.y > 100)
        {
            size.x *= 100 / size.y;
            size.y = 100;
        }
        rect.sizeDelta = size;

        // ��������Ϣ
        BuildingName.key = ChosenBuilding.Name;
        switch (ChosenBuilding.Type)
        {
            case Building.BuildingType.Core:
                BuildingType.key = "Core";
                break;
            case Building.BuildingType.Defense:
                BuildingType.key = "Defence";
                break;
            case Building.BuildingType.Production:
                BuildingType.key = "Production";
                break;
            case Building.BuildingType.Power:
                BuildingType.key = "Power";
                break;
            case Building.BuildingType.Research:
                BuildingType.key = "Research";
                break;
            default:
                BuildingType.key = "Unknown";
                break;
        }

        float baseHeight = 150;
        // ��������ui
        foreach(PannelData.Description description in data.Descriptions.Values)
        {
            GameObject newDescription = GameObject.Instantiate(DescriptionPrefab);
            PannelDescription d = newDescription.GetComponent<PannelDescription>();
            d.BuildingDisplay = ChosenBuilding;

            d.title = description.Title;
            d.content = description.Content;

            d.transform.SetParent(ContentPoint);
            d.transform.localScale = Vector3.one;
            d.transform.localPosition = Vector3.zero;
            baseHeight += 40;

            AdditionalUI.Add(newDescription);
        }
        // ���ƽ�����ui
        foreach(PannelData.Bar bar in data.Bars.Values)
        {
            GameObject newBar = GameObject.Instantiate(BarPrefab);
            PannelBar pannelBar = newBar.GetComponent<PannelBar>();
            pannelBar.BuildingDisplay = ChosenBuilding;

            pannelBar.title = bar.Title;
            pannelBar.color = bar.Color;
            pannelBar.content = bar.Content;
            pannelBar.process = bar.Process;

            pannelBar.transform.SetParent(ContentPoint);
            pannelBar.transform.localScale = Vector3.one;
            pannelBar.transform.localPosition = Vector3.zero;
            baseHeight += 50;

            AdditionalUI.Add(newBar);
        }
        // ���ư�ť
        int rowCount = 0;
        GameObject nowRow = null;
        foreach(PannelData.Button button in data.Buttons.Values)
        {
            rowCount++;
            if(rowCount > 4 || nowRow == null)
            {
                nowRow = GameObject.Instantiate(ButtonRowPrefab);
                nowRow.transform.SetParent(ContentPoint);
                nowRow.transform.localScale = Vector3.one;
                nowRow.transform.localPosition = Vector3.zero;

                rowCount = 1;
                baseHeight += 65;
                AdditionalUI.Add(nowRow);
            }

            GameObject newButton = GameObject.Instantiate(ButtonPrefab);
            PannelButton pannelButton = newButton.GetComponent<PannelButton>();
            pannelButton.BuildingDisplay = ChosenBuilding;

            pannelButton.Title = button.Title;
            pannelButton.Content = button.Content;
            pannelButton.cdEvent = button.CDEvent;
            pannelButton.ClickEvent = button.ClickEvent;
            pannelButton.icon = button.Icon;

            pannelButton.transform.SetParent(nowRow.transform);
            pannelButton.transform.localScale = Vector3.one;
            pannelButton.transform.localPosition = Vector3.zero;
        }
        Rect.sizeDelta = new Vector2(Rect.sizeDelta.x, baseHeight);
    }
    public void ShowButtonText(string title, string content)
    {
        ButtonTextTitle.key = title;
        ButtonTextContent.key = content;
        ButtonTextPannel.SetActive(true);
    }
    public void HideButtonText()
    {
        ButtonTextPannel.SetActive(false);
    }
    private void Awake()
    {
        Main = this;
        Rect = this.transform as RectTransform;
        ButtonTextPannel.SetActive(false);
    }
    private void Update()
    {
        Vector3 localPos = Rect.anchoredPosition;
        if(Mathf.Abs(localPos.x - TargetX) > 1)
        {
            localPos.x += (TargetX - localPos.x) / 6 * Time.unscaledDeltaTime / Time.fixedDeltaTime;
        }
        else
        {
            localPos.x = TargetX;
        }
        Rect.anchoredPosition = localPos;

        if (ChosenBuilding != null && ChosenBuilding.isDead) Choose(null);
    }
}

public class PannelData
{
    public delegate void ButtonClick(Building building);
    public delegate float ButtonCD(Building building);
    public delegate float BarProcess(Building building);
    public delegate string BarContent(Building building);
    public delegate string DescriptionContent(Building building);

    public struct Bar
    {
        public string Title;
        public Color Color;
        public BarContent Content;
        public BarProcess Process;
    }
    public struct Description
    {
        public string Title;
        public DescriptionContent Content;
    }
    public struct Button
    {
        public string Icon;
        public string Title;
        public string Content;
        public ButtonClick ClickEvent;
        public ButtonCD CDEvent;

        public static float ButtonEnable(Building building)
        {
            return 0;
        }
        public static float ButtonDisable(Building building)
        {
            return 1;
        }
    }

    private int NowID = 0;

    public BuildingPannel Pannel;
    public Sprite Preview;
    public Dictionary<int, Bar> Bars = new Dictionary<int, Bar>();
    public Dictionary<int, Button> Buttons = new Dictionary<int, Button>();
    public Dictionary<int, Description> Descriptions = new Dictionary<int, Description>();
    public PannelData(Sprite preview)
    {
        Preview = preview;
    }
    public int AddDescription(string title, DescriptionContent content)
    {
        Description newDes = new Description();
        newDes.Title = title;
        newDes.Content = content;

        Descriptions.Add(NowID, newDes);
        NowID++;
        Repaint();
        return NowID - 1;
    }
    public int ReplaceDescription(int id, string title, DescriptionContent content)
    {
        if (Descriptions.ContainsKey(id))
        {
            Description newDes = new Description();
            newDes.Title = title;
            newDes.Content = content;

            Descriptions[id] = newDes;
            Repaint();
            return id;
        }
        return -1;
    }
    public int AddBar(string title, Color color, BarProcess process, BarContent content)
    {
        Bar newBar = new Bar();
        newBar.Title = title;
        newBar.Color = color;
        newBar.Process = process;
        newBar.Content = content;

        Bars.Add(NowID, newBar);
        NowID++;
        Repaint();
        return NowID - 1;
    }
    public int ReplaceBar(int id, string title, Color color, BarProcess process, BarContent content)
    {
        if (Bars.ContainsKey(id))
        {
            Bar newBar = new Bar();
            newBar.Title = title;
            newBar.Color = color;
            newBar.Process = process;
            newBar.Content = content;

            Bars[id] = newBar;
            Repaint();
            return id;
        }
        return -1;
    }
    public int AddButton(string icon, string title, string content, ButtonClick clickEvent, ButtonCD cdEvent)
    {
        Button newButton = new Button();

        newButton.Icon = icon;
        newButton.Title = title;
        newButton.Content = content;
        newButton.ClickEvent = clickEvent;
        newButton.CDEvent = cdEvent;

        Buttons.Add(NowID, newButton);
        NowID++;
        Repaint();
        return NowID - 1;
    }
    public int ReplaceButton(int id, string icon, string title, string content, ButtonClick clickEvent, ButtonCD cdEvent)
    {
        if (Buttons.ContainsKey(id))
        {
            Button newButton = new Button();

            newButton.Icon = icon;
            newButton.Title = title;
            newButton.Content = content;
            newButton.ClickEvent = clickEvent;
            newButton.CDEvent = cdEvent;

            Buttons[id] = newButton;
            Repaint();
            return id;
        }
        return -1;
    }
    public void RemoveBar(int id)
    {
        if (Bars.ContainsKey(id)) 
        {
            Bars.Remove(id);
            Repaint();
        }
    }
    public void RemoveDescription(int id)
    {
        if (Descriptions.ContainsKey(id))
        {
            Descriptions.Remove(id);
            Repaint();
        }
    }
    public void RemoveButton(int id)
    {
        if (Buttons.ContainsKey(id))
        {
            Buttons.Remove(id);
            Repaint();
        }
    }
    public int AddAttributeDescription(string title, string attributeName)
    {
        return AddDescription(title, (Building building) =>
        {
            float nowAttribute = building.attribute.Get(attributeName);
            float baseAttribute = building.attribute.GetBase(attributeName);

            float displayN = Mathf.FloorToInt(nowAttribute * 100) / 100f;
            float displayB = Mathf.FloorToInt(baseAttribute * 100) / 100f;

            float diff = displayN - displayB;

            if (diff > 0)
            {
                return displayB + " <color=#9AFF9A>+ " + Mathf.Abs(diff) + "</color>";
            }
            else if (diff < 0)
            {
                return displayB + " <color=#FF9A9A>- " + Mathf.Abs(diff) + "</color>";
            }
            else
            {
                return displayB.ToString();
            }
        });
    }
    public int AddHealthBar()
    {
        return AddBar("Health", new Color(0.3f, 0.8f, 0.4f), HealthBarProcess, HealthBarContent);
    }
    public int AddEffeciencyBar()
    {
        return AddBar("Effeciency", new Color(1, 0.9f, 0.35f), EffeciencyBarProcess, EffeciencyBarContent);
    }
    public void Repaint()
    {
        if(Pannel != null) Pannel.Repaint();
    }
    private string EffeciencyBarContent(Building building)
    {
        return Mathf.FloorToInt(building.efficiency * 100) + "%";
    }
    private float EffeciencyBarProcess(Building building)
    {
        return building.efficiency;
    }
    private string HealthBarContent(Building building)
    {
        int health = Mathf.FloorToInt(building.attribute.health);
        int maxHealth = Mathf.FloorToInt(building.attribute.maxHealth);

        return health + "/" + maxHealth;
    }
    private float HealthBarProcess(Building building)
    {
        return building.attribute.healthRate;
    }
}
