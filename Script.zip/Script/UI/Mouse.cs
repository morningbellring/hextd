﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class Mouse : MonoBehaviour
{
    public bool HideMouse = true;
    [SerializeField] private Camera ScreenPositionCamera;
    [SerializeField] private Camera WorldCamera;
    private Animator Animator;

    private static Mouse Main;
    private static int UILayer;

    public static Mouse main
    {
        get
        {
            return Main;
        }
    }
    public Vector3 WorldPosition
    {
        get
        {
            Vector3 screenPoint = ScreenPositionCamera.WorldToScreenPoint(this.transform.position);
            return WorldCamera.ScreenToWorldPoint(new Vector3(screenPoint.x, screenPoint.y, 10));
        }
    }
    private void Awake()
    {
        if (HideMouse) Cursor.visible = false;
        Animator = this.GetComponent<Animator>();
        Main = this;
        UILayer = LayerMask.NameToLayer("UI");
    }
    private void LateUpdate()
    {
        if (HideMouse && Cursor.visible) Cursor.visible = false;
        Vector3 MousePosition = Input.mousePosition;
        MousePosition.z = -ScreenPositionCamera.transform.position.z;
        this.transform.position = ScreenPositionCamera.ScreenToWorldPoint(MousePosition);

        Animator.SetBool("MouseDown", KeyListener.isActive("Point"));
        Animator.SetBool("MouseDrag", KeyListener.isActive("Drag"));
    }
    public static bool IsPointerOverUIElement()
    {
        return IsPointerOverUIElement(GetEventSystemRaycastResults());
    }
    private static bool IsPointerOverUIElement(List<RaycastResult> eventSystemRaysastResults)
    {
        for (int index = 0; index < eventSystemRaysastResults.Count; index++)
        {
            RaycastResult curRaysastResult = eventSystemRaysastResults[index];
            if (curRaysastResult.gameObject.layer == UILayer)
                return true;
        }
        return false;
    }
    private static List<RaycastResult> GetEventSystemRaycastResults()
    {
        PointerEventData eventData = new PointerEventData(EventSystem.current);
        eventData.position = Input.mousePosition;
        List<RaycastResult> raysastResults = new List<RaycastResult>();
        EventSystem.current.RaycastAll(eventData, raysastResults);
        return raysastResults;
    }
}
