using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BuildingProcess : MonoBehaviour
{
    public float rate
    {
        set
        {
            FillImage.fillAmount = value;
        }
    }
    public GameObject followObject
    {
        set
        {
            FollowObject = value;
            if(value.TryGetComponent<Renderer>(out Renderer r))
            {
                Renderer = r;
            }
        }
    }

    private GameObject FollowObject;
    private Renderer Renderer;
    public Image FillImage;
    public Vector3 Offset;

    private Camera MainCamera;
    private Camera SceneCamera;

    private void Start()
    {
        MainCamera = Camera.main;
        SceneCamera = GameObject.Find("Camera/UI").GetComponent<Camera>();
        this.transform.SetParent(GameObject.Find("UI").transform);
        this.transform.localScale = Vector3.one;
        this.transform.localPosition = Vector3.zero;
    }
    private void LateUpdate()
    {
        if (FollowObject != null)
        {
            Vector3 targetPos = Renderer == null ? FollowObject.transform.position : Renderer.bounds.center;
            Vector3 screenPosition = MainCamera.WorldToScreenPoint(targetPos);
            screenPosition.z = 10;
            Vector3 position = SceneCamera.ScreenToWorldPoint(screenPosition) + Offset * 80 / MainCamera.fieldOfView;
            this.transform.position = new Vector3(position.x, position.y, 0);
            this.transform.localScale = Vector3.one * 80 / MainCamera.fieldOfView;
        }
    }
}