using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ElectionicNodeSmall : Building
{
    private int PowerID;
    protected override void OnBuildingStartBuild()
    {
        PannelData.AddAttributeDescription("Defence", "Defence");
        PannelData.AddHealthBar();
        PannelData.AddButton("Test", "Test", "Test", (Building building) =>
        {
            Debug.Log("test button click: " + building);
        }, PannelData.Button.ButtonEnable);
    }
    protected override void OnBuildingComplete()
    {
        PowerID = PowerMap.AddPowerNode(BuildingPosition, 2);
    }
    protected override void OnBuildingDestory()
    {
        PowerMap.DeletePowerNode(PowerID);
    }
}
