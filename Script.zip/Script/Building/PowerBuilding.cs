using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PowerBuilding : Building
{
    public float NowSupply;
    public float Cost;
    protected ResourceType CostResourceType;
    protected float AddSupply_level1 = 1.08f;
    protected float AddSupply_level2 = 1.15f;
    protected float AddSupply_level3 = 1.25f;
    [HideInInspector] public List<Building> Batteries = new List<Building>();
    public void SupplyUpdate()
    {
        StartProduction(efficiency);
    }
    protected virtual void StartProduction(float efficiency)
    {

    }
    protected override void OnBuildingComplete()
    {
        TechnologyUpadate(this.Name);
    }
    protected virtual void TechnologyUpadate(string name)
    {
        Technology.RequireTechnoly(this, "PowerEfficiency", 1, () =>
        {
            NowSupply = AddSupply_level1;
            this.StartProduction(efficiency);
        });
        Technology.RequireTechnoly(this, "PowerEfficiency", 2, () =>
        {
            NowSupply = AddSupply_level2;
            this.StartProduction(efficiency);
        });
        Technology.RequireTechnoly(this, "PowerEfficiency", 3, () =>
        {
            NowSupply = AddSupply_level3;
            this.StartProduction(efficiency);
        });
        Technology.RequireTechnoly(this, "PowerRecycle", 1, () =>
        {
            float ReduceCost = Cost * 0.2f;
            Cost = 0.8f * Cost;
            ResourceManager.AddResourceCost(this.CostResourceType.ToString(),-ReduceCost);
        });
    }
}
