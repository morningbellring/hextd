using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Plant : PowerBuilding
{
    private float SupplyCount = 0;
    protected override void OnBuildingStartBuild()
    {
        Technology.RequireTechnoly(this, "PowerEfficiency", 0, () =>
        {
            NowSupply = 5;
            AddSupply_level1 = AddSupply_level1 * NowSupply;
            AddSupply_level2 = AddSupply_level2 * NowSupply;
            AddSupply_level3 = AddSupply_level3 * NowSupply;
        });
        CostResourceType = ResourceType.Wood;
        Cost = 10;
        PannelData.AddAttributeDescription("Defence", "Defence");
        PannelData.AddEffeciencyBar();
        PannelData.AddHealthBar();
    }
    protected override void OnBuildingEnable()
    { 
        ResourceManager.AddResourceCost("Wood", Cost);
        StartProduction(efficiency);
        
    }
    protected override void OnBuildingDisable()
    {
        ResourceManager.AddResourceCost("Wood", -Cost);
        ResourceManager.AddResourceProduction("Power", -SupplyCount);
        SupplyCount = 0;
    }
    protected override void StartProduction(float efficiency)
    {
        ResourceManager.AddResourceProduction("Power", -SupplyCount);
        SupplyCount = NowSupply * this.efficiency * efficiency;
        ResourceManager.AddResourceProduction("Power", SupplyCount);
    }

    protected override void OnBuildingComplete()
    {
        ResourceManager.AddListener("Wood", this, StartProduction);
    }
    protected override void OnBuildingDestory()
    {

    }
}
