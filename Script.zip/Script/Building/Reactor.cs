using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Reactor : PowerBuilding
{
    private float SupplyCount = 0;

    protected override void OnBuildingStartBuild()
    {
        Technology.RequireTechnoly(this, "PowerEfficiency", 0, () =>
        {
            NowSupply = 50;
            AddSupply_level1 = AddSupply_level1 * NowSupply;
            AddSupply_level2 = AddSupply_level2 * NowSupply;
            AddSupply_level3 = AddSupply_level3 * NowSupply;
        });
        CostResourceType = ResourceType.Metal;
        Cost = 10;
        PannelData.AddAttributeDescription("Defence", "Defence");
        PannelData.AddEffeciencyBar();
        PannelData.AddHealthBar();
    }
    protected override void OnBuildingEnable()
    {
        ResourceManager.AddResourceCost("Metal", Cost);
        StartProduction(efficiency);
    }
    protected override void OnBuildingDisable()
    {
        Debug.Log(Cost);
        ResourceManager.AddResourceProduction("Power", -SupplyCount);
        ResourceManager.AddResourceCost("Metal", -Cost);
        SupplyCount = 0;
    }
    protected override void StartProduction(float efficiency)
    {
        ResourceManager.AddResourceProduction("Power", -SupplyCount);
        SupplyCount = NowSupply * this.efficiency * efficiency;
        ResourceManager.AddResourceProduction("Power", SupplyCount);
    }

    protected override void OnBuildingComplete()
    {
        base.OnBuildingComplete();
        ResourceManager.AddListener("Metal", this, StartProduction);
    }
    protected override void OnBuildingDestory()
    {

    }
}
