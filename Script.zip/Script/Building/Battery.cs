using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Battery : PowerBuilding
{
    private List<Building> BuildingList = new List<Building>();
    protected override void OnBuildingStartBuild()
    {
        PannelData.AddAttributeDescription("Defence", "Defence");
        PannelData.AddHealthBar();
    }
    protected override void OnBuildingComplete()
    {
        BuildingList = Overlap(this.affectArea);
        GlobalMessage.Subscribe("BuildNewBuilding", NewBuildingBuild);
        GlobalMessage.Subscribe("RemoveBuilding", BuildingRemove);
        foreach (Building building in BuildingList)
        {
            if (building.Type == BuildingType.Power)
            {
                PowerBuilding powerBuilding = building as PowerBuilding;
                powerBuilding.Batteries.Add(this);
                if (powerBuilding.Batteries.Count == 1)
                {
                    powerBuilding.CustomEfficiency += 0.2f;
                    powerBuilding.SupplyUpdate();
                }
            }
        }
        ResourceManager.AddResourceToplimit("Power", 20);
    }
    protected override void OnBuildingDestory()
    {
        foreach (Building building in BuildingList)
        {
            if (building.Type == BuildingType.Power)
            {
                PowerBuilding powerBuilding = building as PowerBuilding;
                powerBuilding.Batteries.Remove(this);
                if (powerBuilding.Batteries.Count == 0)
                {
                    powerBuilding.CustomEfficiency -= 0.2f;
                    powerBuilding.SupplyUpdate();
                }
            }
        }
        ResourceManager.AddResourceToplimit("Power", -20);
        GlobalMessage.SubscribeCancel("BuildNewBuilding", NewBuildingBuild);
        GlobalMessage.SubscribeCancel("RemoveBuilding", BuildingRemove);

    }
    private void NewBuildingBuild(object building)
    {
        Building newBuilding = building as Building;
        if (Intersect(this.affectArea, newBuilding.occupyArea) && newBuilding.Type == BuildingType.Power)
        {
            PowerBuilding powerBuilding = building as PowerBuilding;
            BuildingList.Add(newBuilding);
            powerBuilding.Batteries.Add(this);
            if (powerBuilding.Batteries.Count == 1)
            {
                powerBuilding.CustomEfficiency += 0.2f;
                powerBuilding.SupplyUpdate();
            }
        }
    }
    private void BuildingRemove(object building)
    {
        Building newBuilding = building as Building;
        if (BuildingList.Contains(newBuilding) && newBuilding.Type == BuildingType.Power)
        {
            BuildingList.Remove(newBuilding);
        }
    }
}
