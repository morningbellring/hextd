using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Unity.VisualScripting;
using UnityEngine;

public class ElectionicNodeSmall_Level1 : Building
{
    private int PowerID;

    protected override void OnBuildingStartBuild()
    {
        PannelData.AddAttributeDescription("Defence", "Defence");
        PannelData.AddBar("Power", new Color(0.8f,0.7f,0.4f), (Building builiding) =>
        {
            return ResourceManager.GetResourceEffeciency("Power");
        }, (Building builiding) =>
        {
            return ResourceManager.GetResourceEffeciency("Power").ToString();
        }
        );
        PannelData.AddHealthBar();
    }
    private void OnResourceWarning(object data)
    {
        float effciency = (float)data;
    }
    protected override void OnBuildingComplete()
    {
        PowerID = PowerMap.AddPowerNode(BuildingPosition, 3);
    }
    protected override void OnBuildingDestory()
    {
        PowerMap.DeletePowerNode(PowerID);
    }
}
