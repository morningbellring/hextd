using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ElectionicNodeSmall_Level2 : Building
{

    private int PowerID;
    protected override void OnBuildingStartBuild()
    {
        PannelData.AddAttributeDescription("Defence", "Defence");
        PannelData.AddHealthBar();
    }
    protected override void OnBuildingComplete()
    {
        base.OnBuildingComplete();
        PowerID = PowerMap.AddPowerNode(BuildingPosition, 2);
        ResourceManager.AddResourceCost("Power", 10);
    }
    protected override void OnBuildingDestory()
    {
        PowerMap.DeletePowerNode(PowerID);
    }
}
