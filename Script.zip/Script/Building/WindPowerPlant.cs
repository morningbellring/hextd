using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WindPowerPlant : PowerBuilding
{
    private float HaveResource = 1;
    private float SupplyCount = 0;
    private float TempSupply = 2;
    private List<Building> BuildingList = new List<Building>();
    protected override void OnBuildingStartBuild()
    {
        if (ResourceGenerator.GetResourceType(BuildingPosition) != ResourceType.None)
        {
            HaveResource = 0.7f;
        }
        Technology.RequireTechnoly(this, "PowerEfficiency", 0, () =>
        {
            NowSupply = 2;
            AddSupply_level1 = AddSupply_level1 * NowSupply;
            AddSupply_level2 = AddSupply_level2 * NowSupply;
            AddSupply_level3 = AddSupply_level3 * NowSupply;
        });
        CostResourceType = ResourceType.None;
        Cost = 0;
        PannelData.AddAttributeDescription("Defence", "Defence");
        PannelData.AddEffeciencyBar();
        PannelData.AddHealthBar();
        PannelData.AddDescription("Supply", (Building building) => {
            return SupplyCount.ToString();
        });
    }
    protected override void OnBuildingEnable()
    {
        StartProduction(efficiency); 

    }
    protected override void OnBuildingDisable()
    {
        ResourceManager.AddResourceProduction("Power", -SupplyCount);
        SupplyCount = 0;
    }
    protected override void StartProduction(float efficiency)
    {
        ResourceManager.AddResourceProduction("Power", -SupplyCount);
        SupplyCount = TempSupply * HaveResource;
        CustomEfficiency = SupplyCount / NowSupply;
        ResourceManager.AddResourceProduction("Power", SupplyCount);
    }

    protected override void OnBuildingComplete()
    {
        BuildingList = Overlap(this.affectArea);
        GlobalMessage.Subscribe("BuildNewBuilding", NewBuildingBuild);
        GlobalMessage.Subscribe("RemoveBuilding", BuildingRemove);
        TempSupply = NowSupply / BuildingList.Count;
        Debug.Log(TempSupply);
        base.OnBuildingComplete();
        StartProduction(efficiency);
    }
    protected override void OnBuildingDestory()
    {
        base.OnBuildingDestory();
        GlobalMessage.SubscribeCancel("BuildNewBuilding", NewBuildingBuild);
        GlobalMessage.SubscribeCancel("RemoveBuilding", BuildingRemove);
    }
    private void NewBuildingBuild(object building)
    {
        Building newBuilding = building as Building;
        if (Intersect(this.affectArea, newBuilding.occupyArea) && newBuilding.Name == "WindPowerPlant")
        {
            BuildingList.Add(newBuilding);
            TempSupply = NowSupply / BuildingList.Count;
            Debug.Log(TempSupply);
            StartProduction(efficiency);
        }
    }
    private void BuildingRemove(object building)
    {
        Building newBuilding = building as Building;
        if (BuildingList.Contains(newBuilding) && newBuilding.Name == "WindPowerPlant")
        {
            BuildingList.Remove(newBuilding);
            TempSupply = NowSupply / BuildingList.Count;
            StartProduction(efficiency);
        }
    }
}
