using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Core : ResearchBuilding
{
    public static Building main
    {
        get
        {
            return Main;
        }
    }

    private static Building Main;
    protected override void OnBuildingCreate()
    {
        IsRemovable = false;
        BuildingPosition = Vector2Int.zero;
        this.transform.position = TileMap.main.GetWorldPos(Vector2Int.zero);
        StartBuild();
    }
    protected override void OnBuildingStartBuild()
    {
        CancelButton();
        PannelData.AddDescription("WoodStorage", (Building building) => { return "300"; });
        PannelData.AddBar("GoldProduction", ProductionColor, (Building building) => { return 1; }, (Building building) => { return "10/s"; });
        PannelData.AddBar("PowerProduction", ProductionColor, (Building building) => { return 1; }, (Building building) => { return "50/s"; });
        PannelData.AddAttributeDescription("Defence", "Defence");
        PannelData.AddHealthBar();
        Technology.RequireTechnoly(this, "Economics", 1, ecolv1);
        Technology.RequireTechnoly(this, "Economics", 2, ecolv2);
        Technology.RequireTechnoly(this, "Economics", 3, ecolv3);
        
        int Economics =
        AddResearchButton(800, 600, 150, 0, 0, "Economics", 10, 0, "Research_Economics_Level01", "Economics",
              "Level 1:Economics +8%" + "Level 2:Economics +15%" + "Level 3:Economics +25%", HasResource, 3
            );
        //�����¼��������������ȼ��Գ�ʼ���Ľ��������滻

        ReplaceResearchButton(Economics, 1400, 1200, 350, 120, 0, "Economics", 20, 1, Economics, "Research_Economics_Level02", "Economics",
            "Level 1:Economics +8%" + "Level 2:Economics +15%" + "Level 3:Economics +25%", HasResource, 3);
        ReplaceResearchButton(Economics, 2000, 1500, 500, 350, 0, "Economics", 30, 2, Economics, "Research_Economics_Level03", "Economics",
            "Level 1:Economics +8%" + "Level 2:Economics +15%" + "Level 3:Economics +25%", HasResource, 3);
        int DefenseOverLoad = 
        AddResearchButton(600, 1000, 400, 150, 0, "DefenseOverLoad", 1, 0, "Research_DenfseOverload", "DenfenseOverLoad",
              "Unload DenfenseOverload", HasResource, 3);

        
        
        


    }
    private void ecolv1()
    {
        ResourceManager.AddResourceProduction("Power", 5);
    }
    private void ecolv2()
    {
        ResourceManager.AddResourceProduction("Power", 5);
    }
    private void ecolv3()
    {
        ResourceManager.AddResourceProduction("Power", 10);
    }


    protected override void OnBuildingComplete()
    {
        PowerMap.AddPowerNode(Vector2Int.zero, 4);





    }
    protected override void OnBuildingEnable()
    {
        ResourceManager.AddResourceProduction("Power", 50);

        ResourceManager.AddResourceProduction("Gold", 10);
        ResourceManager.AddResourceToplimit("Power", 1000);
        ResourceManager.AddResourceToplimit("Gold", 500);
        ResourceManager.AddResourceToplimit("Wood", 300);
        ResourceManager.AddResourceToplimit("Graphite", 150);
        ResourceManager.AddResourceToplimit("Metal", 200);
    }

    protected void DefenseOverload()
    {

        foreach (DefenseBuilding temp in Building.allBuildings.Values)
        {
            temp.attribute.ReviseRate("AttackSpeed", "DefenseOverload", 0.5f, 10);
        }
        
    }
}
