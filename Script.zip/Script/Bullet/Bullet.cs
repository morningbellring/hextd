using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEditor.Rendering;
using UnityEngine;
using UnityEngine.Rendering.VirtualTexturing;
using UnityEngine.Windows;

public class Bullet : MonoBehaviour
{
    public Vector2 direction

    {
        get
        {
            return Direction;
        }
        set
        {
            Direction = value;
            this.transform.localEulerAngles = new Vector3(0, 0, Mathf.Atan2(value.y, value.x) / Mathf.PI * 180);
        }
    }
    private float lifeProcess
    {
        get
        {
            return NowTime / LifeTime;
        }
    }
    public int lastStrength
    {
        get { return BulletStrenth; }
    }
    [HideInInspector] public EventManager Trigger;

    protected float NowTime = 0;
    public float DamageRate = 1;
    public float RepalForce = 1;
    public float DestoryTime = 0.5f;

    [SerializeField] private float Speed = 4;
    [SerializeField] private float LifeTime = 2;
    [SerializeField] private AnimationCurve SpeedCurve = new AnimationCurve(new Keyframe[] { new Keyframe(0, 1), new Keyframe(1, 1) });
    [SerializeField] private AnimationCurve AngleCurve = new AnimationCurve(new Keyframe[] { new Keyframe(0, 0), new Keyframe(1, 0) });
    [SerializeField] private AnimationCurve TrackCurve = new AnimationCurve(new Keyframe[] { new Keyframe(0, 0.01f), new Keyframe(1, 0.01f) });
    [SerializeField] private int BulletStrenth = 1;

    public GameObject HitEffect;

    private int PenetratedNum = 0;
    protected Transform Target;
    protected Vector2 Direction;
    private Dictionary<Collider2D, float> HittedObject = new Dictionary<Collider2D, float>();
    private Vector3 LastPosition;
    protected LayerMask TargetLayer;
    private Vector3 TargetPosition;

    private bool IsDestory = false;
    private TrailRenderer Trail;
    private ParticleSystem Particle;
    private SpriteRenderer Renderer;

    public void Begin(Transform target,Vector2 direction,LayerMask layer)
    {
        Target = target;
        Direction = direction;
        TargetLayer = layer;
    }
    private void Start()
    {
        float eulerAngle = Mathf.Atan2(Direction.y, Direction.x) / Mathf.PI * 180;
        this.transform.localEulerAngles = new Vector3(0, 0, eulerAngle);
        LastPosition = this.transform.position;

        Trail = this.GetComponent<TrailRenderer>();
        Particle = this.GetComponent<ParticleSystem>();
        Renderer = this.GetComponent<SpriteRenderer>();
    }
    private void Update()
    {
        NowTime += Time.deltaTime;
        if (lifeProcess >= 1) Destory();

        if (IsDestory) return;
        if(Target != null) TargetPosition = Target.position;
        //�ӵ�׷��
        float TargetAngle = Vector2.SignedAngle(Direction,TargetPosition-this.transform.position);
        if (System.Math.Abs(TargetAngle) > TrackCurve.Evaluate(NowTime / LifeTime) /2*180)
        {
            TargetAngle = TrackCurve.Evaluate(NowTime / LifeTime) / 2 * 180 * System.Math.Abs(TargetAngle)/ TargetAngle;
        }
        this.transform.localEulerAngles += new Vector3(0, 0, TargetAngle + AngleCurve.Evaluate(NowTime / LifeTime) / 2 * 180);
        Direction = new Vector2(Mathf.Cos(this.transform.localEulerAngles.z / 180 * Mathf.PI), Mathf.Sin(this.transform.localEulerAngles.z / 180 * Mathf.PI)).normalized;
        Speed = SpeedCurve.Evaluate(lifeProcess) *Speed;
        float Dx = Speed * Direction.x * Time.timeScale/100;
        float Dy = Speed * Direction.y * Time.timeScale/100;
        this.transform.position += new Vector3(Dx, Dy, 0);
        //��ײ���
        RaycastHit2D[] TempObject = Physics2D.LinecastAll(LastPosition, this.transform.position, TargetLayer);
        foreach (RaycastHit2D rh in TempObject)
        {
            if (!HittedObject.ContainsKey(rh.collider))
            {
                HittedObject.Add(rh.collider, NowTime);
                if(rh.collider.TryGetComponent<EventManager>(out EventManager em))
                {
                    Hit(em);
                    PenetratedNum++;
                    if (PenetratedNum >= BulletStrenth)
                    {
                        Destory();
                        break;
                    }
                }
            }
        }
        List<Collider2D> RemoveColiider = new List<Collider2D>();
        foreach (Collider2D gb in HittedObject.Keys)
        {
            if (NowTime > HittedObject[gb] + 0.5)
            {
                RemoveColiider.Add(gb);
            }
        }
        foreach (Collider2D gb in RemoveColiider)
        {
            HittedObject.Remove(gb);
        }
        LastPosition = this.transform.position;
    }
    private void Hit(EventManager em)
    {
        if(Trigger != null)
        {
            Trigger.Repal(em, RepalForce, direction);
            Trigger.Damage(em, DamageRate);
            if(HitEffect != null)
            {
                GameObject effect = GameObject.Instantiate(HitEffect);
                effect.transform.position = this.transform.position;
                effect.transform.localEulerAngles = new Vector3(0, 0, Mathf.Atan2(Direction.y, Direction.x) / Mathf.PI * 180);
            }
            HitTarget(em);
        }
    }
    protected void Destory()
    {
        if (Trail != null) Trail.emitting = false;
        if (Renderer != null) Renderer.enabled = false;
        if (Particle != null)
        {
            ParticleSystem.EmissionModule module = Particle.emission;
            module.enabled = false;
        }
        IsDestory = true;
        GameObject.Destroy(this.gameObject, DestoryTime);
    }
    protected virtual void HitTarget(EventManager em)
    {

    }
}
