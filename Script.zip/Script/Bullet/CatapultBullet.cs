using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CatapultBullet : Bullet
{
    public float CatapultRange = 3.5f;
    public int CatapultAmount = 5;
    public float stun_time = 0.4f;

    private Dictionary<Collider2D, int> CatapultedTarget = new Dictionary<Collider2D, int>();
    protected override void HitTarget(EventManager em)
    {
        base.HitTarget(em);
        em.Attribute.ReviseRate("Speed", "CatapultBullet1", -0.99f, stun_time);
        if (em.TryGetComponent<Collider2D>(out Collider2D targetCollider) && !CatapultedTarget.ContainsKey(targetCollider))
        {
            CatapultedTarget.Add(targetCollider, CatapultAmount);
        }
        if(lastStrength > 0 && CatapultAmount > 0)
        {
            Collider2D[] colliders = Physics2D.OverlapCircleAll(this.transform.position, CatapultRange, TargetLayer);
            Collider2D newTarget = null;
            float nowRange = CatapultRange + 100;

            foreach(Collider2D c in colliders)
            {
                float distance = Vector2.Distance(c.transform.position, this.transform.position);
                if(distance <= nowRange && !CatapultedTarget.ContainsKey(c))
                {
                    nowRange = distance;
                    newTarget = c;
                }
            }
            if(newTarget != null)
            {
                NowTime = 0;
                Target = newTarget.transform;
                direction = ((Vector2)(newTarget.transform.position - this.transform.position)).normalized;
                CatapultedTarget.Add(newTarget, CatapultAmount);
                CatapultAmount--;
            }
            else
            {
                Destory();
            }
        }
    }
}
