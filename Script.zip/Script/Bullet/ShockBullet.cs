using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShockBullet : Bullet
{
    public float slow_rate;
    public float slow_time;

    protected override void HitTarget(EventManager em)
    {
        base.HitTarget(em);
        Collider2D[] enemy_list = Physics2D.OverlapCircleAll(Target.transform.position, 3f, TargetLayer);
        foreach (Collider2D temp in enemy_list)
        {
            if (temp.TryGetComponent<AttributeManager>(out AttributeManager am))
            {
                am.ReviseRate("Speed", "ShockBlaster", -slow_rate, slow_time);
            }
        }
    }

}
