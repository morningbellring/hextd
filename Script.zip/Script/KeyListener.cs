﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KeyListener : MonoBehaviour
{
    public class KeyEvent
    {
        public bool Active = false;
        public int KeyCode;
        public event KeyDown DownEvent;
        public event KeyUp UpEvent;
        public KeyEvent(int keyCode)
        {
            KeyCode = keyCode;

            DownEvent = new KeyDown(NullRecall);
            UpEvent = new KeyUp(NullRecall);
        }
        public void Down()
        {
            Active = true;
            DownEvent();
        }
        public void Up()
        {
            Active = false;
            UpEvent();
        }
        private void NullRecall() { }
    }
    public delegate void KeyDown();
    public delegate void KeyUp();

    private static Dictionary<string, KeyEvent> Config = new Dictionary<string, KeyEvent>();

    private void Awake()
    {
        foreach(KeyValuePair<string, string> kvp in ConfigReader.Get("KeyConfig"))
        {
            KeyEvent keyEvent = new KeyEvent(int.Parse(kvp.Value));
            Config.Add(kvp.Key, keyEvent);
        }
    }

    private void Update()
    {
        foreach (KeyValuePair<string, KeyEvent> kvp in Config)
        {
            switch (kvp.Value.KeyCode)
            {
                case 10001:
                    if(Input.GetAxis("Mouse ScrollWheel") > 0)
                    {
                        kvp.Value.Down();
                        kvp.Value.Up();
                    }
                    break;
                case 10002:
                    if (Input.GetAxis("Mouse ScrollWheel") < 0)
                    {
                        kvp.Value.Down();
                        kvp.Value.Up();
                    }
                    break;
                default:
                    if (Input.GetKeyDown((KeyCode)kvp.Value.KeyCode))
                    {
                        kvp.Value.Down();
                    }
                    if (Input.GetKeyUp((KeyCode)kvp.Value.KeyCode))
                    {
                        kvp.Value.Up();
                    }
                    break;
            }
            
        }
    }

    public static bool isActive(string eventName)
    {
        return Config[eventName].Active;
    }
    public static KeyEvent GetEvent(string eventName)
    {
        if (Config.ContainsKey(eventName))
        {
            return Config[eventName];
        }
        return null;
    }
}
