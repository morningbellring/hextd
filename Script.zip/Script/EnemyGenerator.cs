using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyGenerator : MonoBehaviour
{
    public static int waveCount
    {
        get
        {
            return WaveTime.Count;
        }
    }
    public static float generateAmount
    {
        set
        {
            if (value <= 0) GenerateInterval = 0;
            else GenerateInterval = 60 / value;
        }
        get
        {
            return GenerateInterval * 60;
        }
    }
    public static float waveLastTime
    {
        get
        {
            return WaveLastTime;
        }
    }
    public static float nextWaveTime
    {
        get
        {
            float time = NextWaveTime - NowGameTime;
            return time >= 0 ? time : 0;
        }
    }
    public static bool isAllWaveEnd
    {
        get
        {
            return WaveTime.Count == 0 && WaveLastTime <= 0;
        }
    }
    private static float NextWaveTime = 0;
    private static float WaveLastTime = 0;
    private static float GenerateInterval = -1;
    private float NowGenerateTime = 0;
    [SerializeField] private GameObject EnemyPrefab;
    [SerializeField] private AudioClip WaveBGM;

    private static float NowGameTime;
    private static float NowEnemyStrength = 100;
    private static List<float> EnemyAmount = new List<float>()
    {
        100,
        180,
        280,
        400,
        660,
        1000
    };
    private static List<float> EnemyStrength = new List<float>()
    {
        1000,
        180,
        280,
        400,
        660,
        1000
    };
    private static List<float> EnemyLastTime = new List<float>()
    {
        5,
        90,
        120,
        120,
        240,
        240
    };
    private static List<float> WaveTime = new List<float>()
    {
        5
    };
    private void Start()
    {
        NextWaveTime = WaveTime[0];
    }
    private void Update()
    {
        NowGameTime += Time.deltaTime;
        if(NowGameTime > NextWaveTime - 20 && WaveTime.Count > 0 && BGM.isDefault)
        {
            BGM.Play(WaveBGM);
        }
        if(NowGameTime > NextWaveTime && WaveTime.Count > 0)
        {
            NowEnemyStrength = EnemyStrength[0];
            WaveLastTime = EnemyLastTime[0];
            generateAmount = EnemyAmount[0];

            WaveTime.RemoveAt(0);
            EnemyStrength.RemoveAt(0);
            EnemyLastTime.RemoveAt(0);
            EnemyAmount.RemoveAt(0);

            if(WaveTime.Count > 0) NextWaveTime = WaveTime[0];
        }
        if(WaveLastTime > 0)
        {
            WaveLastTime -= Time.deltaTime;
            if(WaveLastTime <= 0)
            {
                generateAmount = 0;
                WaveLastTime = 0;
                BGM.ReturnDefault();
            }
        }

        if (GenerateInterval <= 0) return;
        NowGenerateTime += Time.deltaTime;
        while(NowGenerateTime > GenerateInterval)
        {
            NowGenerateTime -= GenerateInterval;

            float randomAngle = Random.Range(0, Mathf.PI * 2);

            GameObject enemyObject = GameObject.Instantiate(EnemyPrefab);
            enemyObject.transform.position = new Vector2(Mathf.Cos(randomAngle), Mathf.Sin(randomAngle)) *
                (Building.maxRange + 20 + Random.value * 2);

            float randomStrength = Random.value * 0.4f + 0.8f;
            float size = (Mathf.Sqrt(NowEnemyStrength) / 100 + 0.15f) * randomStrength;
            enemyObject.transform.localScale = Vector3.one * size;

            Enemy enemy = enemyObject.GetComponent<Enemy>();
            enemy.attribute.ChangeBaseValue("MaxHealth", NowEnemyStrength * randomStrength);
            enemy.attribute.ChangeBaseValue("Damage", (40 + NowEnemyStrength * 0.3f) * randomStrength);
            enemy.attribute.ChangeBaseValue("Speed", 0.35f + Mathf.Sqrt(NowEnemyStrength) / 100);
        }
    }
}
