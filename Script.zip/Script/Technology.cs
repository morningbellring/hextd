﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Unity.VisualScripting;

public class Technology
{
    private struct TechCall
    {
        public Building Building;
        public int Level;
        public TechRequirment Requirment;
    }
    public delegate void TechRequirment();

    public static Dictionary<string, int> tech_list = new Dictionary<string, int>();
    private static Dictionary<string, List<TechCall>> RequirmentList = new Dictionary<string, List<TechCall>>();
    public static bool Check(string tech) 
    {
        return tech_list.ContainsKey(tech) ? tech_list[tech] > 0 : false;
    }
    public static int GetLevel(string tech)
    {
        return tech_list.ContainsKey(tech) ? tech_list[tech] : 0;
    }

    public static void Upgrade(string tech)
    {
        if (!tech_list.ContainsKey(tech)) tech_list.Add(tech, 1);
        else tech_list[tech] += 1;
        GlobalMessage.Send("TechLevelChange_" + tech, tech_list[tech]);

        if (RequirmentList.ContainsKey(tech))
        {
            for(int i = RequirmentList[tech].Count - 1; i >= 0; i--)
            {
                TechCall call = RequirmentList[tech][i];
                if(call.Building == null)
                {
                    RequirmentList[tech].RemoveAt(i);
                    continue;
                }
                if (tech_list[tech] >= call.Level)
                {
                    call.Requirment();
                    RequirmentList[tech].RemoveAt(i);
                }
            }
        }
    }
    public static void Degrade(string tech)
    {
        if (!tech_list.ContainsKey(tech)) tech_list.Add(tech, -1);
        else tech_list[tech] -= 1;
        GlobalMessage.Send("TechLevelChange_" + tech, tech_list[tech]);
    }
    public static void RequireTechnoly(Building building, string tech, int level, TechRequirment callEvent)
    {
        if(GetLevel(tech) >= level)
        {
            callEvent();
        }
        else
        {
            TechCall call = new TechCall();
            call.Building = building;
            call.Level = level;
            call.Requirment = callEvent;

            if (!RequirmentList.ContainsKey(tech))
            {
                List<TechCall> newList = new List<TechCall>();
                RequirmentList.Add(tech, newList);
                
            }
            RequirmentList[tech].Add(call);
        }
    }
}

