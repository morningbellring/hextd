using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HammerControl : GunControl
{


    void Start()
    {
        stage_fire = 0; 
    }

    void Update()
    {
        move_fire();
    }

    //��̨ǰ�˶���
    protected override void move_back()
    {
        if (Mathf.Abs(transform.localPosition.y) < length)
        {
            transform.localPosition += new Vector3(0,speed_fire * Time.deltaTime,0);
        }
        else if(Mathf.Abs(transform.localPosition.y) >= length)
        {
            transform.localPosition = new Vector3(0, -length, 0);
            stage_fire = 2;
        }
    }

    //��̨��ȥ����
    protected override void move_forward()
    {
        if (Mathf.Abs(transform.localPosition.y) >= 0.005f)
        {
            transform.localPosition -= new Vector3(0, force_back * Time.deltaTime * Mathf.Abs(transform.localPosition.y),0);
        }
        else
        {
            transform.localPosition = new Vector3(0, 0, 0);
            stage_fire = 0;
        }  
    }


}


