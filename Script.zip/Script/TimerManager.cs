using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class TimerManager : MonoBehaviour
{
    private static Dictionary<int, Timer> Timers = new Dictionary<int, Timer>();
    private static Dictionary<int, Timer> WaitTimers = new Dictionary<int, Timer>();
    public static void AddTimer(Timer timer, int id)
    {
        WaitTimers.Add(id, timer);
    }
    public static void RemoveTimer(int id)
    {
        if (Timers.ContainsKey(id)) Timers.Remove(id);
        else if (WaitTimers.ContainsKey(id)) WaitTimers.Remove(id);
    }
    public static bool HasTimer(int id)
    {
        return Timers.ContainsKey(id) || WaitTimers.ContainsKey(id);
    }
    private void Update()
    {
        foreach(KeyValuePair<int, Timer> kvp in WaitTimers)
        {
            Timers.Add(kvp.Key, kvp.Value);
        }
        WaitTimers.Clear();

        List<int> removeID = new List<int>();
        foreach(Timer t in Timers.Values)
        {
            if (t.Stop) continue;
            t.lastTime -= Time.deltaTime * t.timeScale;
            if(t.lastTime <= 0)
            {
                removeID.Add(t.id);
            }
        }
        foreach(int i in removeID)
        {
            Timers.Remove(i);
        }
    }
}
public class Timer
{
    private static int TimerID = 0;
    public float lastTime
    {
        get
        {
            return LastTime;
        }
        set
        {
            LastTime = value;
            if(IsBind && BindTarget == null)
            {
                LastTime = 0;
            }
            else if (LastTime <= 0)
            {
                LastTime = 0;
                Complete();
            }
        }
    }
    public int id
    {
        get
        {
            return ID;
        }
    }
    public float lastRate
    {
        get
        {
            return 1 - LastTime / FirstTime;
        }
    }
    public float timeScale
    {
        get
        {
            return TimeScale == null ? 1 : TimeScale();
        }
    }
    public bool Stop;
    private bool IsBind = false;
    private int ID;
    private float LastTime;
    private float FirstTime;
    private TimerEvent Complete;
    private CustomTime TimeScale;
    private Building BindTarget;

    public delegate void TimerEvent();
    public delegate float CustomTime();
    public Timer(float time, TimerEvent completeEvent, CustomTime timeScale = null)
    {
        LastTime = time;
        FirstTime = time;
        Complete = completeEvent;
        TimeScale = timeScale;
        ID = TimerID;
        TimerID++;
    }
    public void Bind(Building building)
    {
        IsBind = true;
        BindTarget = building;
    }
    public void Start()
    {
        LastTime = FirstTime;
        if (!TimerManager.HasTimer(ID))
        {
            TimerManager.AddTimer(this, ID);
        }
    }
    public void Cancel()
    {
        if (TimerManager.HasTimer(ID))
        {
            TimerManager.RemoveTimer(ID);
        }
    }
    public float PannelProcess(Building building)
    {
        return lastRate;
    }
    public float CD(Building building)
    {
        if (lastRate == 1 || lastRate == 0) { return 0; }
            return 1 - lastRate;
    }
    public string PannelDescription(Building building)
    {
        return Mathf.FloorToInt(FirstTime - LastTime).ToString() +  "/" + Mathf.FloorToInt(FirstTime).ToString();
    }
}