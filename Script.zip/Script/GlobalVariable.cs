using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GlobalVariable : MonoBehaviour
{
    public static Sprite Wood;
    public static Sprite Metal;
    public static Sprite Gold;
    public static Sprite Graphite;
    public static Sprite Power;

    [SerializeField] private Sprite wood;
    [SerializeField] private Sprite metal;
    [SerializeField] private Sprite gold;
    [SerializeField] private Sprite graphite;
    [SerializeField] private Sprite power;

    private void Awake()
    {
        
    }
}
