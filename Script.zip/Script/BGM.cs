using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BGM : MonoBehaviour
{
    public static bool isDefault
    {
        get
        {
            return TargetBGM == DefaultBGM;
        }
    }
    public static BGM Main;
    [SerializeField] private AudioSource AudioPlayer;
    
    private static float NowVolume = 1;
    private static AudioClip DefaultBGM;
    private static AudioClip TargetBGM;
    private void Start()
    {
        Main = this;
        DefaultBGM = AudioPlayer.clip;
        TargetBGM = AudioPlayer.clip;
    }
    public static void ReturnDefault()
    {
        if (TargetBGM == DefaultBGM) return;
        Play(DefaultBGM);
    }
    public static void Play(AudioClip clip)
    {
        if (clip == TargetBGM) return;
        TargetBGM = clip;
        NowVolume = -1;
    }
    public void Update()
    {
        if(NowVolume < 1)
        {
            float targetV = NowVolume + UnityEngine.Time.deltaTime;
            if(NowVolume < 0 && targetV >= 0)
            {
                AudioPlayer.clip = TargetBGM;
                AudioPlayer.Play();
            }
            if (NowVolume > 1) NowVolume = 1;
            AudioPlayer.volume = Mathf.Abs(targetV);
            NowVolume = targetV;
        }
    }
}
