using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using static UnityEngine.GraphicsBuffer;

public class AOE : MonoBehaviour
{
    public EventManager Trigger;

    public bool Enable;
    public Collider2D Collider;
    public LayerMask Layer;
    public float Interval = 1;
    public float DamageRate = 0.5f;
    public int MaxAmount = 99;
    public float SameTargetInterval = 0;


    private List<Collider2D> HittedList = new List<Collider2D>();
    private List<float> HittedTime = new List<float>();
    private float NowTime = 0;
    private ContactFilter2D ContactFilter;

    private void Start()
    {
        ContactFilter = new ContactFilter2D();
        ContactFilter.layerMask = Layer;
    }
    private void Update()
    {
        if (Enable && Trigger != null) NowTime += Time.deltaTime;

        for(int i = HittedList.Count - 1; i >= 0; i--)
        {
            HittedTime[i] -= Time.deltaTime;
            if (HittedTime[i] <= 0)
            {
                HittedList.RemoveAt(i);
                HittedTime.RemoveAt(i);
            }
        }

        while (NowTime >= Interval && Interval > 0)
        {
            NowTime -= Interval;
            Collider2D[] targets = new Collider2D[MaxAmount];
            int amount = Collider.OverlapCollider(ContactFilter, targets);
            for(int i = 0; i < amount; i++)
            {
                if (!HittedList.Contains(targets[i]) && targets[i].TryGetComponent<EventManager>(out EventManager targetEM))
                {
                    HitTarget(targetEM);
                    if (SameTargetInterval > 0)
                    {
                        HittedList.Add(targets[i]);
                        HittedTime.Add(SameTargetInterval);
                    }
                }
            }
        }
    }
    protected virtual void HitTarget(EventManager em)
    {
        Trigger.Damage(em, DamageRate);
    }
}
