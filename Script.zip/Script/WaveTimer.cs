using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class WaveTimer : MonoBehaviour
{
    public TextMeshProUGUI Text;
    public TextMeshProUGUI WaveText;
    public Image WaveIcon;

    private void Update()
    {
        float lastTime = 0;
        if(EnemyGenerator.waveLastTime > 0)
        {
            WaveIcon.color = Color.red;
            lastTime = EnemyGenerator.waveLastTime;
            Text.color = Color.white;
        }
        else
        {
            WaveIcon.color = Color.white;
            lastTime = EnemyGenerator.nextWaveTime;
            Text.color = lastTime < 20 ? Color.red : Color.white;
        }

        int min = Mathf.FloorToInt(lastTime / 60);
        int sec = Mathf.FloorToInt(lastTime - min * 60);

        Text.text = string.Format("{0:D2}:{1:D2}", min, sec);

        WaveText.text = EnemyGenerator.waveCount.ToString();
        WaveText.color = EnemyGenerator.waveCount > 1 ? Color.white : Color.red;
    }
}
