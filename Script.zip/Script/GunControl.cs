using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GunControl : MonoBehaviour
{
    [HideInInspector] public Building Building;

    public float force_back;
    public float speed_fire;
    public float length;

    protected int stage_fire;
    protected float fire_interval;
    protected Transform pivot;

    public Vector2 direction
    {
        get
        {
            float nowAngle = -this.transform.eulerAngles.z / 180 * Mathf.PI;
            return new Vector2(Mathf.Sin(nowAngle), Mathf.Cos(nowAngle));
        }
    }

    //Ŀ��ӿ�

    void Start()
    {
        stage_fire = 0; 
    }

    void Update()
    {
        move_fire();
    }

    //��̨���˶���
    protected virtual void move_back()
    {
        if (Mathf.Abs(transform.localPosition.y) < length)
        {
            transform.localPosition -= new Vector3(0,speed_fire * Time.deltaTime,0);
        }
        else if(Mathf.Abs(transform.localPosition.y) >= length)
        {
            transform.localPosition = new Vector3(0, -length, 0);
            stage_fire = 2;
        }
    }

    //��̨��ȥ����
    protected virtual void move_forward()
    {
        if (Mathf.Abs(transform.localPosition.y) >= 0.005f)
        {
            transform.localPosition += new Vector3(0, force_back * Time.deltaTime * Mathf.Abs(transform.localPosition.y),0);
        }
        else
        {
            transform.localPosition = new Vector3(0, 0, 0);
            stage_fire = 0;
        }  
    }

    //������
    public void move_fire()
    {
        if (stage_fire == 1)
        {
            move_back();
        }

        else if(stage_fire == 2)
        {
            move_forward();
        }
    }

    public virtual void Fire(Collider2D target)
    {
        stage_fire = 1; 
    }
}


