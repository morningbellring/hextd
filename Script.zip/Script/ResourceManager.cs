using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ResourceManager : MonoBehaviour
{
    public static float gold
    {
        get
        {
            return GetResource("Gold");
        }
    }
    public static float wood
    {
        get
        {
            return GetResource("Wood");
        }
    }
    public static float metal
    {
        get
        {
            return GetResource("Metal");
        }
    }
    public static float graphite
    {
        get
        {
            return GetResource("Graphite");
        }
    }
    public static float power
    {
        get
        {
            return GetResource("Power");
        }
    }

    public delegate void ResourceListener(float efficiency);
    private struct Listener 
    {
        public Building Building;
        public ResourceListener Event;
    }

    private static Dictionary<string, float> ResourceAmount = new Dictionary<string, float>();
    private static Dictionary<string, float> ResourceProduction = new Dictionary<string, float>();
    private static Dictionary<string, float> ResourceCost = new Dictionary<string, float>();
    private static Dictionary<string, float> ResourceToplimit = new Dictionary<string, float>();

    private static Dictionary<string, float> ResourceCostRecord = new Dictionary<string, float>();
    private static Dictionary<string, float> ResourceRecord = new Dictionary<string, float>();

    private static Dictionary<string, List<Listener>> Listeners = new Dictionary<string, List<Listener>>();

    private static Dictionary<string, float> ResourceProductionWait = new Dictionary<string, float>();
    public static void AddResource(string resource, float amount)
    {
        if (ResourceAmount.ContainsKey(resource))
        {
            ResourceAmount[resource] += amount;
            if (ResourceAmount[resource] > ResourceToplimit[resource]) ResourceAmount[resource] = ResourceToplimit[resource];
            else if (ResourceAmount[resource] < 0) ResourceAmount[resource] = 0;
        }
    }
    public static void AddResourceProduction(string resource, float amount)
    {
        if (ResourceProduction.ContainsKey(resource))
        {
            if (ResourceProductionWait.ContainsKey(resource)) ResourceProductionWait[resource] += amount;
            else ResourceProductionWait.Add(resource, amount);
        }
    }
    public static void AddResourceCost(string resource, float amount)
    {
        if (ResourceCost.ContainsKey(resource)) ResourceCost[resource] += amount;
    }
    public static void AddResourceToplimit(string resource, float amount)
    {
        if (ResourceToplimit.ContainsKey(resource)) ResourceToplimit[resource] += amount;
    }
    public static float GetResource(string resource)
    {
        if (ResourceAmount.ContainsKey(resource)) return ResourceAmount[resource];
        return 0;
    }
    public static float GetResourceIncreasment(string resource)
    {
        if (ResourceProduction.ContainsKey(resource)) return ResourceProduction[resource] - ResourceCost[resource];
        return 0;
    }
    public static float GetResourceProduction(string resource)
    {
        if (ResourceProduction.ContainsKey(resource)) return ResourceProduction[resource];
        return 0;
    }
    public static float GetResourceCost(string resource)
    {
        if (ResourceCost.ContainsKey(resource)) return ResourceCost[resource];
        return 0;
    }
    public static float GetResourceToplimit(string resource)
    {
        if (ResourceToplimit.ContainsKey(resource)) return ResourceToplimit[resource];
        return 0;
    }
    public static float GetResourceEffeciency(string resource)
    {
        if (ResourceProduction.ContainsKey(resource) && ResourceProduction[resource] > 0)
        {
            float value = ResourceProduction[resource] / ResourceCost[resource];
            return value > 1 ? 1 : value;
        }
        return 0;
    }
    public static void AddListener(string resourceName, Building building, ResourceListener listener)
    {
        if (!Listeners.ContainsKey(resourceName)) return;
        listener(GetResourceEffeciency(resourceName));

        Listener l = new Listener();
        l.Building = building;
        l.Event = listener;

        Listeners[resourceName].Add(l);
    }
    public static bool HasResource(string resourceName, float amount)
    {
        if (ResourceAmount.ContainsKey(resourceName))
        {
            return ResourceAmount[resourceName] >= amount;
        }
        return false;
    }
    public static bool HasResource(float gold = 0, float wood = 0, float metal = 0, float graphite = 0, float power = 0)
    {
        return ResourceAmount["Gold"] >= gold && ResourceAmount["Wood"] >= wood &&
            ResourceAmount["Metal"] >= metal && ResourceAmount["Graphite"] >= graphite &&
            ResourceAmount["Power"] >= power;
    }
    private static void SendEfficiency(string resourceName)
    {
        float efficiency = GetResourceEffeciency(resourceName);

        for(int i = Listeners[resourceName].Count - 1; i >= 0; i--)
        {
            if (Listeners[resourceName][i].Building == null)
            {
                Listeners[resourceName].RemoveAt(i);
            }
            else
            {
                Listeners[resourceName][i].Event(efficiency);
            }
        }
    }
    private static void AddResourceType(string resource)
    {
        ResourceAmount.Add(resource, 0);
        ResourceProduction.Add(resource, 0);
        ResourceCost.Add(resource, 0);
        ResourceToplimit.Add(resource, 0);
        ResourceCostRecord.Add(resource, 0);
        ResourceRecord.Add(resource, 0);
        Listeners.Add(resource, new List<Listener>());
    }
    private void Awake()
    {
        AddResourceType("Gold");
        AddResourceType("Wood");
        AddResourceType("Metal");
        AddResourceType("Graphite");
        AddResourceType("Power");
    }
    private void FixedUpdate()
    {
        foreach(KeyValuePair<string, float> kvp in ResourceProductionWait)
        {
            ResourceProduction[kvp.Key] += kvp.Value;
        }
        ResourceProductionWait.Clear();

        foreach (KeyValuePair<string, float> kvp in ResourceProduction)
        {
            float value = kvp.Value - ResourceCost[kvp.Key];
            AddResource(kvp.Key, value * Time.fixedDeltaTime);

            // ����Դ����������ʱ
            if(value < 0)
            {
                // �жϸ���Դ�����Ƿ��㹻
                if (ResourceAmount[kvp.Key] > 0 && ResourceRecord[kvp.Key] <= 0)
                {
                    // ���в�����Դ��������Դ�����¼�
                    GlobalMessage.Send("ResourceWarning-" + kvp.Key, 1);
                    SendEfficiency(kvp.Key);
                }
                else if (ResourceAmount[kvp.Key] <= 0 && value != ResourceCostRecord[kvp.Key])
                {
                    // ����������Դ�����ı䣬������ԴЧ�ʸ����¼�
                    GlobalMessage.Send("ResourceWarning-" + kvp.Key, kvp.Value / ResourceCost[kvp.Key]);
                    SendEfficiency(kvp.Key);
                }
            }
            // ����Դ�����ָ�ʱ��������Դ�����¼�
            if ((value >= 0 && ResourceCostRecord[kvp.Key] < 0))
            {
                GlobalMessage.Send("ResourceWarning-" + kvp.Key, 1);
                SendEfficiency(kvp.Key);
            }

            ResourceCostRecord[kvp.Key] = value;
            ResourceRecord[kvp.Key] = ResourceAmount[kvp.Key];
        }
    }
}
