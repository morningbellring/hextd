using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TileMap : MonoBehaviour
{
    public static TileMap main
    {
        get { return Main; }
    }
    private static TileMap Main;

    private Vector2Int PositionOffset = Vector2Int.zero;
    private Vector2Int LastPositionOffset = Vector2Int.zero;

    private bool ShowPower = false;
    private Dictionary<Vector2Int, Color> RangePos = new Dictionary<Vector2Int, Color>();

    public float XOffset = 1.09f;
    public float YOffset = 0.95f;

    private float Size = 1;

    [SerializeField]
    private GameObject GirdPrefab;

    private Camera MainCamera;

    private Dictionary<Vector2Int, Gird> PosGirds = new Dictionary<Vector2Int, Gird>();
    //private Gird[][] Girds;

    public Vector2Int mousePos
    {
        get
        {
            /*Vector2 basePos = Mouse.main.WorldPosition;
            float minDistance = 999999;
            Vector2Int targetPos = Vector2Int.zero;

            foreach (Gird g in PosGirds.Values)
            {
                float distance = Vector2.Distance(g.transform.position, basePos);
                if (distance < minDistance)
                {
                    minDistance = distance;
                    targetPos = g.position;
                }
            }*/

            return GetMapPos(Mouse.main.WorldPosition);
        }
    }
    public Vector2Int GetMapPos(Vector2 worldPos)
    {
        Vector2Int roundPos = Vector2Int.zero;

        roundPos.x = Mathf.FloorToInt(worldPos.x / XOffset);
        roundPos.y = -Mathf.FloorToInt(worldPos.y / (YOffset * 2)) * 2;

        worldPos.x -= roundPos.x * XOffset;
        worldPos.y -= -roundPos.y * YOffset;

        roundPos.x -= roundPos.y / 2;

        worldPos.y *= 0.995f;
        worldPos.x += worldPos.y * 0.5f / YOffset * XOffset;

        float q = (Mathf.Sqrt(3) / 3 * worldPos.x - 1 / 3 * worldPos.y) / Size;
        float r = -(2f / 3f * worldPos.y) / Size;

        Vector2Int axPos = Vector2Int.RoundToInt(AxialRound(new Vector2(q, r)));
        //axPos.x -= Mathf.CeilToInt(axPos.y / 2);

        return axPos + roundPos;
    }
    private Vector3 AxialToCube(Vector2 hex)
    {
        return new Vector3(hex.x, hex.y, -hex.x - hex.y);
    }
    private Vector2 CubeToAxial(Vector3 cube)
    {
        return new Vector2(cube.x, cube.y);
    }
    private Vector2 AxialRound(Vector2 hex)
    {
        return CubeToAxial(CubeRound(AxialToCube(hex)));
    }
    private Vector3 CubeRound(Vector3 frac)
    {
        int q = Mathf.RoundToInt(frac.x);
        int r = Mathf.RoundToInt(frac.y);
        int s = Mathf.RoundToInt(frac.z);

        float qDiff = Mathf.Abs(q - frac.x);
        float rDiff = Mathf.Abs(r - frac.y);
        float sDiff = Mathf.Abs(s - frac.z);

        if (qDiff > rDiff && qDiff > sDiff) q = -r - s;
        else if (rDiff > sDiff) r = -q - s;
        else s = -q - r;

        return new Vector3(q, r, s);
    }
    public Vector2 GetWorldPos(Vector2Int mapPos)
    {
        mapPos -= PositionOffset;
        if (PosGirds.ContainsKey(mapPos))
        {
            return PosGirds[mapPos].transform.position;
        }
        return Vector2.zero;
    }
    public void ShowPowerMap()
    {
        ShowPower = true;
        foreach (Gird g in PosGirds.Values)
        {
            g.showPowerMap = true;
            if (RangePos.ContainsKey(g.position))
            {
                g.bgColor = RangePos[g.position];
            }
        }
    }
    public void HidePowerMap()
    {
        ShowPower = false;
        foreach (Gird g in PosGirds.Values)
        {
            g.showPowerMap = false;
            if (RangePos.ContainsKey(g.position))
            {
                g.bgColor = RangePos[g.position];
            }
        }
    }
    public void ShowBuildingRange(List<Vector2Int> rangePos, Color color)
    {
        RangePos.Clear();
        if (rangePos.Count == 0) return;
        foreach(Vector2Int pos in rangePos)
        {
            RangePos.Add(pos, color);
        }
        foreach(Gird g in PosGirds.Values)
        {
            if (RangePos.ContainsKey(g.position))
            {
                g.bgColor = color;
            }
            else if (ShowPower)
            {
                g.showPowerMap = true;
            }
            else g.showPowerMap = false;
        }
    }
    public void HideBuildingRange()
    {
        RangePos.Clear();
        if (ShowPower)
        {
            ShowPowerMap();
        }
        else
        {
            HidePowerMap();
        }
    }
    private void Awake()
    {
        Main = this;
        Size = XOffset / Mathf.Sqrt(3);
        MainCamera = Camera.main;

        //Girds = new Gird[36][];
        int posY = 18;
        int xOffset = -8;
        float nowY = -YOffset * 18;
        for (int i = 0; i < 36; i++)
        {
            int posX = -25 + xOffset;
            float nowX = -XOffset * 25 + (i % 2 == 0 ? XOffset / 2 : 0) + XOffset / 2;
            //Gird[] row = new Gird[50];
            for (int j = 0; j < 50; j++)
            {
                GameObject girdObject = GameObject.Instantiate(GirdPrefab);

                girdObject.transform.SetParent(this.transform);
                girdObject.transform.localPosition = new Vector3(nowX, nowY, 0);
                girdObject.transform.localScale = Vector3.one;

                Gird gird = girdObject.GetComponent<Gird>();
                Vector2Int pos = new Vector2Int(posX, posY);
                gird.BasePos = pos;

                PosGirds.Add(pos, gird);
                //row[j] = gird;
                nowX += XOffset;
                posX++;
            }
            //Girds[i] = row;
            nowY += YOffset;
            posY--;
            xOffset += (i % 2 == 0 ? 0 : 1);
        }

        GlobalMessage.Subscribe("AddPowerNode", (object data) => { if (ShowPower) ShowPowerMap(); });
        GlobalMessage.Subscribe("RemovePowerNode", (object data) => { if (ShowPower) ShowPowerMap(); });

        LastPositionOffset = Vector2Int.one * 100;
        Update();
    }
    private void Update()
    {
        MainCamera = Camera.main;

        PositionOffset.x = Mathf.FloorToInt(MainCamera.transform.position.x / XOffset);
        PositionOffset.y = -Mathf.FloorToInt(MainCamera.transform.position.y / (YOffset * 2)) * 2;

        float x = PositionOffset.x * XOffset;
        float y = -PositionOffset.y * YOffset;

        this.transform.position = new Vector3(x, y, 0);

        PositionOffset.x -= PositionOffset.y / 2;

        if (LastPositionOffset != PositionOffset)
        {
            LastPositionOffset = PositionOffset;
            foreach (Gird g in PosGirds.Values)
            {
                g.positionOffset = PositionOffset;
                if (RangePos.ContainsKey(g.position))
                {
                    g.bgColor = RangePos[g.position];
                }
                else
                {
                    g.bgColor = Color.white * 0f;
                }
            }
        }
    }
}
