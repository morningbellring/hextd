using System.Collections.Generic;
using UnityEngine;

public  enum ResourceType
{
    None,
    Wood,
    Metal,
    Graphite
}

public class ResourceGenerator
{
    private const int SafeDistance = 8;
    private const int CacheDistance = 30;
    private const int CacheAmount = 100000;

    private static Vector2Int OpenedPoint;

    private static int BaseSeed = 999999;
    private static Dictionary<Vector2Int, ResourceType> Cache = new Dictionary<Vector2Int, ResourceType>();
    private static List<Vector2Int> CacheSortList = new List<Vector2Int>();
    public static int seed
    {
        set
        {
            BaseSeed = value;
        }
    }
    private static void SetSeed(Vector2Int pos)
    {
        UnityEngine.Random.InitState(BaseSeed + pos.x * 10000 + pos.y);
    }
    public static ResourceType GetResourceType(Vector2Int pos)
    {
        if (!Cache.ContainsKey(pos))
        {
            float nowTime = UnityEngine.Time.realtimeSinceStartup;
            OpenPoint(pos);
        }
        return Cache[pos];
    }
    private static void OpenPoint(Vector2Int pos)
    {
        OpenedPoint = pos;
        List<Vector2Int> calArea = GetPositionInRange(pos, CacheDistance + SafeDistance);

        foreach (Vector2Int calPos in calArea)
        {
            int distance = Distance(calPos, Vector2Int.zero);
            ResourceType type = GenerateType(calPos, distance);
            int baseValue = 1;
            int floatValue = 1;
            switch (type)
            {
                case ResourceType.None:
                    OverlapPoint(calPos, ResourceType.None);
                    break;
                case ResourceType.Wood:
                    baseValue = Mathf.RoundToInt(((distance < 8 ? distance / 64 : 0.25f) + 0.75f) * (4 + UnityEngine.Random.value * 3));
                    floatValue = Mathf.RoundToInt(((distance < 8 ? distance / 64 : 0.25f) + 0.75f) * (8 + UnityEngine.Random.value * 8));
                    Generate(calPos, UnityEngine.Random.Range(baseValue, floatValue), ResourceType.Wood);
                    break;
                case ResourceType.Metal:
                    baseValue = Mathf.RoundToInt(((distance < 22 ? distance / 44 : 0.5f) + 0.5f) * (3 + UnityEngine.Random.value * 1));
                    floatValue = Mathf.RoundToInt(((distance < 22 ? distance / 44 : 0.5f) + 0.5f) * (7 + UnityEngine.Random.value * 3));
                    Generate(calPos, UnityEngine.Random.Range(baseValue, floatValue), ResourceType.Metal);
                    break;
                case ResourceType.Graphite:
                    baseValue = Mathf.RoundToInt(((distance < 34 ? distance / 68 : 0.5f) + 0.5f) * (2 + UnityEngine.Random.value * 3));
                    floatValue = Mathf.RoundToInt(((distance < 34 ? distance / 68 : 0.5f) + 0.5f) * (4 + UnityEngine.Random.value * 6));
                    Generate(calPos, UnityEngine.Random.Range(baseValue, floatValue), ResourceType.Graphite);
                    break;
            }
        }
    }
    private static void Generate(Vector2Int pos, int amount, ResourceType type)
    {
        List<Vector2Int> waitList = new List<Vector2Int>();
        Dictionary<Vector2Int, bool> waitDict = new Dictionary<Vector2Int, bool>();
        Dictionary<Vector2Int, bool> generateList = new Dictionary<Vector2Int, bool>();

        generateList.Add(pos, false);
        OverlapPoint(pos, type);

        Vector2Int temp = pos + new Vector2Int(-1, 1);
        waitList.Add(temp);
        waitDict.Add(temp, false);

        temp = pos + new Vector2Int(0, 1);
        waitList.Add(temp);
        waitDict.Add(temp, false);

        temp = pos + new Vector2Int(-1, 0);
        waitList.Add(temp);
        waitDict.Add(temp, false);

        temp = pos + new Vector2Int(1, 0);
        waitList.Add(temp);
        waitDict.Add(temp, false);

        temp = pos + new Vector2Int(0, -1);
        waitList.Add(temp);
        waitDict.Add(temp, false);

        temp = pos + new Vector2Int(1, -1);
        waitList.Add(temp);
        waitDict.Add(temp, false);

        amount--;
        for (;amount > 0; amount--)
        {
            int index = UnityEngine.Random.Range(0, waitList.Count);
            Vector2Int chosenPos = waitList[index];

            waitDict.Remove(chosenPos);
            waitList.RemoveAt(index);

            generateList.Add(chosenPos, false);
            OverlapPoint(chosenPos, type);

            PushGeneratePoint(waitList, waitDict, generateList, chosenPos + new Vector2Int(-1, 1), pos);
            PushGeneratePoint(waitList, waitDict, generateList, chosenPos + new Vector2Int(0, 1), pos);
            PushGeneratePoint(waitList, waitDict, generateList, chosenPos + new Vector2Int(-1, 0), pos);
            PushGeneratePoint(waitList, waitDict, generateList, chosenPos + new Vector2Int(1, 0), pos);
            PushGeneratePoint(waitList, waitDict, generateList, chosenPos + new Vector2Int(0, -1), pos);
            PushGeneratePoint(waitList, waitDict, generateList, chosenPos + new Vector2Int(1, -1), pos);
        }
    }
    private static void PushGeneratePoint
        (List<Vector2Int> waitList,
        Dictionary<Vector2Int, bool> waitDict,
        Dictionary<Vector2Int, bool> generateList,
        Vector2Int pushPoint,
        Vector2Int center)
    {
        if(!waitDict.ContainsKey(pushPoint) && !generateList.ContainsKey(pushPoint) && Distance(pushPoint, center) <= SafeDistance)
        {
            waitDict.Add(pushPoint, false);
            waitList.Add(pushPoint);
        }
    }
    private static void AddCache(Vector2Int pos, ResourceType type)
    {
        if(Distance(pos, OpenedPoint) < CacheDistance)
        {
            Cache.Add(pos, type);
            CacheSortList.Add(pos);
            if(CacheSortList.Count > CacheAmount)
            {
                for(int i = 0; i < 300; i++)
                {
                    Cache.Remove(CacheSortList[0]);
                    CacheSortList.RemoveAt(0);
                }
            }
        }
    }
    private static ResourceType GenerateType(Vector2Int pos, int distance)
    {
        SetSeed(pos);

        float value = UnityEngine.Random.value;
        
        float woodC = (distance < 8 ? distance / 8 : 1) * 0.003f + 0.007f;
        float metalC = distance > 6 ? ((distance < 22 ? distance / 22 : 1) * 0.004f + 0.004f) : 0;
        float graphiteC = distance > 12 ? ((distance < 34 ? distance / 34 : 1) * 0.003f + 0.003f) : 0;

        return RandomChoose(value, woodC, metalC, graphiteC);
    }
    private static void OverlapPoint(Vector2Int pos, ResourceType resource)
    {
        if (Cache.ContainsKey(pos))
        {
            ResourceType baseType = Cache[pos];
            switch (resource)
            {
                case ResourceType.None:
                    break;
                case ResourceType.Wood:
                    switch (baseType)
                    {
                        case ResourceType.Wood:
                        case ResourceType.Metal:
                        case ResourceType.Graphite:
                            break;
                        default:
                            Cache[pos] = resource;
                            break;
                    }
                    break;
                case ResourceType.Metal:
                    switch (baseType)
                    {
                        case ResourceType.Metal:
                        case ResourceType.Graphite:
                            break;
                        default:
                            Cache[pos] = resource;
                            break;
                    }
                    break;
                case ResourceType.Graphite:
                    Cache[pos] = resource;
                    break;
            }
        }
        else AddCache(pos, resource);
    }
    private static ResourceType RandomChoose(float value, float wood, float metal, float graphite)
    {
        if (value < wood)
        {
            return ResourceType.Wood;
        }
        else if (value < wood + metal)
        {
            return ResourceType.Metal;
        }
        else if (value < wood + metal + graphite)
        {
            return ResourceType.Graphite;
        }
        return ResourceType.None;
    }
    private static List<Vector2Int> GetPositionInRange(Vector2Int point, int range)
    {
        List<Vector2Int> resultList = new List<Vector2Int>();
        for(int i = -range; i < range; i++)
        {
            for (int j = -range; j < range; j++)
            {
                Vector2Int newVector = point + new Vector2Int(i, j);
                if (Distance(point, newVector) < range)
                {
                    resultList.Add(newVector);
                }
            }
        }
        return resultList;
    }
    private static int Distance(Vector2Int a, Vector2Int b)
    {
        return (Mathf.Abs(a.x - b.x) + Mathf.Abs(a.x + a.y - b.x - b.y)  + Mathf.Abs(a.y - b.y)) / 2;
    }
}