using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using Unity.VisualScripting;
using UnityEditor.TerrainTools;
using UnityEditor.VersionControl;
using UnityEngine;
using UnityEngine.UIElements;

public class PowerMap
{
    static int IDNum = 0;
    //����һ�������ڵ���
    public class PowerNode
    {
        public Vector2Int Position;
        public int Range;
        public bool state = false;
        public int ID = 0;
        public List<PowerNode> PowerSupply = new List<PowerNode>();
        public PowerNode(Vector2Int position, int range)
        {
            this.Position = position;
            this.Range = range;
        }
    }
    private static int hex_distance(Vector2Int a,Vector2Int b)
    {
        return (Mathf.Abs(a.x - b.x)
          + Mathf.Abs(a.x + a.y - b.x - b.y)
          + Mathf.Abs(a.y - b.y))/2;
    }
    static List<PowerNode> PowerNodes = new List<PowerNode>();
    //���ӽڵ��������
    public static int AddPowerNode(Vector2Int positon,int range)
    {
        PowerNode TempNode =new PowerNode(positon, range);
        if (positon == Vector2Int.zero)
        {
            TempNode.state = true;
        }
        IDNum++;
        TempNode.ID = IDNum;
        //�ж��½ڵ��Ƿ���ԭ�нڵ㹩�緶Χ�в��������ӽ�����ڵ�Ĺ����б���
        foreach(PowerNode t in PowerNodes)
        {
            if (hex_distance(t.Position, TempNode.Position) <= t.Range)
            {
                if(t.state == true)
                {
                    TempNode.state = true;
                }
                t.PowerSupply.Add(TempNode);
            }
        }
        foreach (PowerNode t in PowerNodes)
        {
            if (hex_distance(t.Position, TempNode.Position) <= TempNode.Range)
            {
                if (TempNode.state == true)
                {
                    t.state = true;
                }
                TempNode.PowerSupply.Add(t);
            }
        }
        PowerNodes.Add(TempNode);
        GlobalMessage.Send("AddPowerNode", null);
        return TempNode.ID;
    }
    private static void DFS(List<PowerNode> TempList,PowerNode TempNode)
    {
        if (!TempList.Contains(TempNode))
        {
            TempList.Add(TempNode);
            if (TempNode.PowerSupply.Count > 0 )
            {
                foreach (PowerNode t in TempNode.PowerSupply)
                {
                    DFS(TempList, t);
                }
            }
        }
    }
    //ɾ�������ڵ�
    public static void DeletePowerNode(int ID)
    {
        PowerNode TempNode=null;
        //�����������ڵ�Ĺ����б���ɾ��Ŀ������ڵ�
        foreach(PowerNode t in PowerNodes)
        {
            if(t.ID == ID)
            {
                foreach(PowerNode e in PowerNodes)
                {
                    if (e.PowerSupply.Contains(t))
                    {
                        e.PowerSupply.Remove(t);
                    }
                }
                TempNode = t;
                break;
            }
        }
        PowerNodes.Remove(TempNode);
        //DFS�����ҳ�ɾ���ڵ�����е�Ľڵ�
        List<PowerNode> TempList = new List<PowerNode>();
        DFS(TempList, PowerNodes[0]);
        foreach (PowerNode t in PowerNodes)
        {
            if (TempList.Contains(t))
            {
                t.state = true;
            }
            else
            {
                t.state = false;
            }
        }
        GlobalMessage.Send("RemovePowerNode", null);
    }
    public static bool IsPowered(Vector2Int position)
    {
        bool isPowered = false;
        foreach(PowerNode t in PowerNodes)
        {
            if (t.state == true)
            {
                if (hex_distance(t.Position, position) <= t.Range)
                {
                    isPowered = true;
                    break;
                }
            }
        }
        return isPowered;
    }
    public static bool IsPowered(Vector2Int[] positions)
    {
        foreach(Vector2Int pos in positions)
        {
            if (!IsPowered(pos)) return false;
        }
        return true;
    }
}
