using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class Gird : MonoBehaviour
{
    public static Color WoodColor = new Color(0.35f, 0.31f, 0.27f, 1);
    public static Color MetalColor = new Color(0.35f, 0.35f, 0.35f, 1);
    public static Color GraphiteColor = new Color(0.26f, 0.26f, 0.35f, 1);

    public Vector2Int positionOffset
    {
        set
        {
            Offset = value;
            Vector2Int pos = value + BasePos;
            //Text.text = pos.x.ToString() + "," + pos.y.ToString();
            ResourceType type = ResourceGenerator.GetResourceType(pos);
            switch (type)
            {
                case ResourceType.Wood:
                    Resource.sprite = WoodIcon;
                    Resource.color = WoodColor;
                    break;
                case ResourceType.Metal:
                    Resource.sprite = MetalIcon;
                    Resource.color = MetalColor;
                    break;
                case ResourceType.Graphite:
                    Resource.sprite = GraphiteIcon;
                    Resource.color = GraphiteColor;
                    break;
                default:
                    Resource.sprite = null;
                    break;
            }
            if (ShowPowerMap) showPowerMap = true;
        }
    }
    public Vector2Int position
    {
        get
        {
            return BasePos + Offset;
        }
    }
    public bool showPowerMap
    {
        set
        {
            ShowPowerMap = value;
            if (ShowPowerMap)
            {
                BackGround.enabled = true;
                BackGround.color = PowerMap.IsPowered(position) ? new Color(0.8f, 0.7f, 0.4f, 0.7f) : new Color(1, 1, 1, 0);
            }
            else
            {
                BackGround.enabled = false;
            }
        }
    }
    public Color bgColor
    {
        set
        {
            BackGround.enabled = value.a > 0;
            BackGround.color = value;
        }
    }
    [HideInInspector] public Vector2Int BasePos;
    private Vector2Int Offset;
    public SpriteRenderer Resource;
    public SpriteRenderer BackGround;

    public Sprite WoodIcon;
    public Sprite MetalIcon;
    public Sprite GraphiteIcon;
    //public TextMeshPro Text;

    private bool ShowPowerMap;
}
