using System;
using System.Collections.Generic;
using UnityEngine;

public class HexagonalMap
{
    public static Vector2Int Hexagon = new Vector2Int();//����������
    public static Dictionary<Vector2Int, List<Vector2Int>> adjacentHexagons = new Dictionary<Vector2Int, List<Vector2Int>>();//��Ϊ����ӵ�е����ֵ꣬Ϊ��֮���ڵ������б����ֵ�
    public static Dictionary<string, List<Vector2Int>> ActivatedErct = new Dictionary<string, List<Vector2Int>>();//��Ϊһ������ռ�е����ֵ꣬Ϊ�����������
    public static Dictionary<string, List<Vector2Int>> UnActivatedErct = new Dictionary<string, List<Vector2Int>>();



    private static bool IfAdjacented(Vector2Int hex1, Vector2Int hex2)//�����ж�����������Ƿ�����
    {
        // ��������������Ĳ�ֵ
        Vector2Int offset = hex2 - hex1;

        // ��������������ϵ�Ĺ����ж����ڹ�ϵ
        if ((offset.x == 1 && offset.y == 0) ||              // ��
            (offset.x == -1 && offset.y == 0) ||             // ��
            (offset.x == 0 && offset.y == 1) ||              // ����
            (offset.x == 0 && offset.y == -1) ||             // ����
            (offset.x == 1 && offset.y == -1) ||             // ����
            (offset.x == -1 && offset.y == 1))               // �� ��
        {
            return true;
        }

        return false;
    }


    private static Dictionary<string, List<Vector2Int>> AddErctToAdjacentHexagon(List<Vector2Int> Erct, string buildingID)
    {

        ActivatedErct[buildingID] = Erct;
        for (int i = 0; i < Erct.Count; i++)
        {
            Vector2Int currentHex = Erct[i];
            List<Vector2Int> adjacentList = new List<Vector2Int>();
            foreach (Vector2Int a in adjacentHexagons.Keys)
            {
                if (a != currentHex && IfAdjacented(currentHex, a) && !adjacentHexagons[a].Contains(currentHex))
                {
                    adjacentHexagons[a].Add(currentHex);
                    adjacentList.Add(a);
                }
            }
            // �����������������꣬�ж��Ƿ�����
            for (int j = 0; j < Erct.Count; j++)
            {
                if (i != j && IfAdjacented(currentHex, Erct[j]) && !adjacentList.Contains(Erct[j]))
                {
                    adjacentList.Add(Erct[j]);
                }
            }

            // �������������б����ӵ��ֵ���
            adjacentHexagons[currentHex] = adjacentList;
        }
        return ActivatedErct;
    }
    private static Dictionary<Vector2Int, List<Vector2Int>> DeleErctToAdjacentHexagon(List<Vector2Int> Erct) //����һ�����������꣬�Ա����ֵ�adjacentHexagons��ɾ��������ݲ����ֵ�ActivatedErctɾ���ý���
    {

        foreach (var hex in Erct)
        {
            foreach (var adjHex in adjacentHexagons[hex])
            {
                adjacentHexagons[adjHex].Remove(hex);
            }
            adjacentHexagons.Remove(hex);
        }
        return adjacentHexagons;
    }

    private static List<Vector2Int> GetAdjacentHexagons(Vector2Int hex)//��ȡװ����hex���ڵ�������б�
    {
        if (adjacentHexagons.ContainsKey(hex))
        {
            return adjacentHexagons[hex];
        }

        return new List<Vector2Int>();
    }

    private static Boolean FindPath(Vector2Int goal)//�ж�һ�������Ƿ���ԭ������
    {

        Vector2Int start = new Vector2Int(0, 0);

        var openSet = new List<Vector2Int> { start };
        var cameFrom = new Dictionary<Vector2Int, Vector2Int>();
        var gScore = new Dictionary<Vector2Int, float>();
        var fScore = new Dictionary<Vector2Int, float>();

        foreach (var hex in adjacentHexagons.Keys)
        {
            gScore[hex] = float.MaxValue;
            fScore[hex] = float.MaxValue;
        }

        gScore[start] = 0;
        fScore[start] = HeuristicCostEstimate(start, goal);

        while (openSet.Count > 0)
        {
            var current = GetLowestFScore(openSet, fScore);
            if (current == goal)
            {
                return true; //ReconstructPath(cameFrom, current);
            }

            openSet.Remove(current);

            foreach (var neighbor in GetAdjacentHexagons(current))
            {
                var tentativeGScore = gScore[current] + 1; // Assuming uniform cost for each hexagon

                if (tentativeGScore < gScore[neighbor])
                {
                    cameFrom[neighbor] = current;
                    gScore[neighbor] = tentativeGScore;
                    fScore[neighbor] = gScore[neighbor] + HeuristicCostEstimate(neighbor, goal);

                    if (!openSet.Contains(neighbor))
                    {
                        openSet.Add(neighbor);
                    }
                }
            }
        }

        return false; // No path found
    }

    private static float HeuristicCostEstimate(Vector2Int start, Vector2Int goal)
    {
        // Implement your heuristic function here
        // This example uses the Euclidean distance between two hexagons as the heuristic

        return (float)Math.Sqrt(Math.Pow(goal.x - start.x, 2) + Math.Pow(goal.y - start.y, 2));
    }

    private static Vector2Int GetLowestFScore(List<Vector2Int> openSet, Dictionary<Vector2Int, float> fScore)
    {
        float lowestFScore = float.MaxValue;
        Vector2Int lowestHexagon = new Vector2Int(0, 0);


        foreach (var hex in openSet)
        {
            if (fScore[hex] < lowestFScore)
            {
                lowestFScore = fScore[hex];
                lowestHexagon = hex;
            }
        }

        return lowestHexagon;
    }

    private static bool IsActivated(List<Vector2Int> occupyArea)//�ж�һ�������Ƿ񼤻�(����ӵ��һ����ԭ�����ڵ�����)
    {
        foreach (var hex in occupyArea)
        {
            if (FindPath(hex))
            {
                return true;
            }
        }
        return false;
    }
    public static List<string> RemoveBuilding(List<Vector2Int> occupyArea, string buildingId)
    {
        string j = "";
        List<string> unactivateBuild = new List<string>();
        foreach (var i in ActivatedErct.Keys)
        {   
            
            if (i == buildingId)
            {
                DeleErctToAdjacentHexagon(occupyArea);
                j = i;
            }
        }
        foreach (var h in UnActivatedErct.Keys) {
            if (h == buildingId)
            {
                UnActivatedErct.Remove(h);
                DeleErctToAdjacentHexagon(occupyArea);
                return unactivateBuild;

            }

        }
        ActivatedErct.Remove(j);
        
        
        List<string> keys = new List<string>(ActivatedErct.Keys);
        foreach (var i in keys)
        {
            if (!IsActivated(ActivatedErct[i]))
            {
                unactivateBuild.Add(i);
                UnActivatedErct[i] = ActivatedErct[i];
                ActivatedErct.Remove(i);
            }

        }


        return unactivateBuild;

    }
    public static List<string> AddBuilding(List<Vector2Int> occupyArea, string buildingID)
    {


        List<string> ReActivate_Builds = new List<string>();
        if (UnActivatedErct.Count == 0) //����ͼ��û��δ����Ľ���ʱ
        {

            AddErctToAdjacentHexagon(occupyArea, buildingID);
            return ReActivate_Builds;
        }

        AddErctToAdjacentHexagon(occupyArea, buildingID);
        List<string> keys = new List<string>(UnActivatedErct.Keys);
        foreach (var i in keys)
        {
            AddErctToAdjacentHexagon(UnActivatedErct[i], i);
            if (IsActivated(UnActivatedErct[i]))
            {
                ReActivate_Builds.Add(i);
                UnActivatedErct.Remove(i);
            }
            else
            {
                DeleErctToAdjacentHexagon(UnActivatedErct[i]);


            }
        }
        return ReActivate_Builds;
    }
    public static bool IsBuildable(List<Vector2Int> occupyArea)
    {
        foreach (var i in occupyArea)
        {
            if (adjacentHexagons.ContainsKey(i))
            {
                return false;
            }
        }
        AddErctToAdjacentHexagon(occupyArea, "temp_test");
        foreach (var i in occupyArea)
        {
            if (FindPath(i))
            {
                DeleErctToAdjacentHexagon(occupyArea);
                ActivatedErct.Remove("temp_test");
                return true;
            }

        }
        ActivatedErct.Remove("temp_test");
        DeleErctToAdjacentHexagon(occupyArea);
        return false;



    }


}


/*
public class HexMapGenerator : MonoBehaviour
{
    public static void Main(string[] args)
    {
        // Create a hexagonal map and add adjacent hexagons
        
      
    }
    private void Start()
    {   
        var map = new HexagonalMap();
        

     
        Vector2Int hex1 = new Vector2Int(0, 0);
        Vector2Int hex2 = new Vector2Int(0, -1);
        Vector2Int hex3 = new Vector2Int(0, -2);
        Vector2Int hex4 = new Vector2Int(0, -3);
        Vector2Int hex5 = new Vector2Int(1, 0);
        Vector2Int hex6 = new Vector2Int(1, -1);
        Vector2Int hex7 = new Vector2Int(1, -2);
        Vector2Int hex8 = new Vector2Int(1, -3);
        Vector2Int hex9 = new Vector2Int(2, 0);
        Vector2Int hex10 = new Vector2Int(2, -1);
        Vector2Int hex11 = new Vector2Int(2, -2);
        Vector2Int hex12 = new Vector2Int(2, -3);
        Vector2Int hex13 = new Vector2Int(3, 0);
        Vector2Int hex14 = new Vector2Int(3, -1);
        Vector2Int hex15 = new Vector2Int(3, -2);
        Vector2Int hex16 = new Vector2Int(3, -3);
      
        List<Vector2Int> test = new List<Vector2Int>();
        List<Vector2Int> test2 = new List<Vector2Int>();
        List<Vector2Int> origin = new List<Vector2Int>();
        List<Vector2Int> test3 = new List<Vector2Int>();

        origin.Add(hex1);
        test.Add(hex6);
        test.Add(hex11);
        test2.Add(hex16);
        test3.Add(hex13);
        test3.Add(hex14);
        test3.Add(hex9);
        test3.Add(hex15);
        



        Dictionary<List<Vector2Int>, string> origin_test = map.AddErctToAdjacentHexagon(origin, "origin");
        Dictionary<List<Vector2Int>, string> adjecented =  map.AddErctToAdjacentHexagon(test,"test");
        Dictionary<List<Vector2Int>, string> adjecented2 = map.AddErctToAdjacentHexagon(test2, "test2");
        foreach (var a in map.RemoveBuilding(test)) {
            Debug.Log(a + "�Ѿ�ʧЧ");
        }
        if (map.IsBuildable(test3)) { Debug.Log(1); }
        foreach (var a in map.AddBuilding(test,"test")) {
            Debug.Log(a + "�Ѿ����¼���");
        }
        if (map.IsBuildable(test3)) { Debug.Log("��������"); }












    }
    private void Update()
    {
    }
}

*/