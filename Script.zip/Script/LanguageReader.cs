using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

public class LanguageReader
{
    public delegate void LanguageEvent();
    public static event LanguageEvent ChangeLanguage;

    private static Dictionary<string, Loaded> LoadedText = new Dictionary<string, Loaded>();
    private static Dictionary<int, TextFile> LanguageList = new Dictionary<int, TextFile>();
    private static int Language = -10;
    private static int ChosenLanguage = 0;
    private static bool IsInit = false;
    private static string Path = "";

    private class Loaded
    {
        public string Key;
        public TextFile TextFile;
        public Loaded(string key, string path)
        {
            Key = key;
            TextFile = new TextFile(path);
        }
    }
    public static int language
    {
        set
        {
            Init();
            Debug.Log("language:" + value);
            if ((!LanguageList.ContainsKey(value) && value != -1) || value == Language) return;
            Debug.Log("Choose language: " + value.ToString());
            ConfigReader.Write("Setting", "Language", value.ToString());
            Language = value;
            ChosenLanguage = value;
            if(Language == -1)
            {
                int systemLanguage = (int)Application.systemLanguage;
                if (LanguageList.ContainsKey(systemLanguage))
                {
                    ChosenLanguage = systemLanguage;
                }
                else
                {
                    ChosenLanguage = 10;
                    Debug.Log("unsupported language: " + Application.systemLanguage);
                }
            }
            Path = Application.streamingAssetsPath + "/Languages/" + LanguageList[ChosenLanguage].Get("Default", "dirname") + "/";
            LoadedText.Clear();
            ChangeLanguage();
        }
        get
        {
            Init();
            return Language;
        }
    }
    public static string systemLanguage
    {
        get
        {
            Init();
            int sl = (int)Application.systemLanguage;
            if (LanguageList.ContainsKey(sl))
            {
                return LanguageList[sl].Get("Default", "auto");
            }
            return "��֧�ֵ�ϵͳ����";
        }
    }
    public static Dictionary<string, int> languages
    {
        get
        {
            Init();
            Dictionary<string, int> l = new Dictionary<string, int>();
            foreach(KeyValuePair<int, TextFile> kvp in LanguageList)
            {
                l.Add(kvp.Value.Get("Default", "name"), kvp.Key);
            }
            return l;
        }
    }
    public static void Init()
    {
        if (IsInit) return;
        IsInit = true;
        ChangeLanguage += () => { };

        LanguageList.Clear();
        LoadedText.Clear();
        string path = Application.streamingAssetsPath + "/Languages";
        DirectoryInfo root = new DirectoryInfo(path);
        DirectoryInfo[] Readlanguages = root.GetDirectories();
        for(int i = Readlanguages.Length - 1; i >= 0; i--)
        {
            string infoPath = Readlanguages[i].FullName + "\\config.txt";
            if (File.Exists(infoPath))
            {
                TextFile info = new TextFile(infoPath);
                LanguageList.Add(int.Parse(info.Get("Default", "id")), info);
            }
        }

        int initL = int.Parse(ConfigReader.Get("Setting", "Language"));
        if (!LanguageList.ContainsKey(initL))
        {
            initL = -1;
        }
        language = initL;
    }
    public static bool Has(string fileName, string textID)
    {
        Init();
        if (LoadedText.TryGetValue(fileName, out Loaded l))
        {
            return l.TextFile.Has("Default", textID);
        }
        return false;
    }
    public static string Read(string fileName, string textID)
    {
        Init();
        if (LoadedText.TryGetValue(fileName, out Loaded l))
        {
            return l.TextFile.Get("Default", textID);
        }
        float time = UnityEngine.Time.realtimeSinceStartup;
        Loaded newLoaded = new Loaded(fileName, Path + fileName + ".txt");
        // if (LoadedText.Count > 30) LoadedText.RemoveAt(30);
        LoadedText.Add(fileName, newLoaded);
        return newLoaded.TextFile.Get("Default", textID);
    }
    // private void LoadFile()
}
