﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class GlobalMessage
{
    public delegate void message_handler(Object message);
    public static Dictionary<string, message_handler> MessageList = new Dictionary<string, message_handler>();

    public static void Subscribe(string messageName, message_handler handle)
    {
        if (!MessageList.ContainsKey(messageName))
        {
            MessageList.Add(messageName, new message_handler(handle));
        }
        else
        {
            MessageList[messageName] += handle;
        }
    }

    public static void SubscribeCancel(string messageName, message_handler handle)
    {
        if (MessageList.ContainsKey(messageName))
        {
            MessageList[messageName] -= handle;
            if (MessageList[messageName] == null)
            {
                MessageList.Remove(messageName);
            }
        }
    }

    public static void Send(string messageName, object data)
    {
        if (MessageList.ContainsKey(messageName))
        {
            MessageList[messageName](data);
        }
    }

}


