﻿using System.Collections.Generic;
using System.IO;
using UnityEngine;
using System.Text.RegularExpressions;

public class TextFile
{
    public Dictionary<string, Dictionary<string, string>> ConfigList = new Dictionary<string, Dictionary<string, string>>();

    private string Path;
    private bool ConfigChange = false;

    public TextFile(string path)
    {
        Path = path;
        if (!File.Exists(Path))
        {
            Debug.LogError("File not existing:" + Path);
            return;
        }
        StreamReader StrReader = new StreamReader(Path);
        string Group = "Default";
        Dictionary<string, string> GroupDict = new Dictionary<string, string>();

        while (!StrReader.EndOfStream)
        {
            string LineContent = StrReader.ReadLine();
            bool Topic = Regex.IsMatch(LineContent, @"^\[.*\]$");
            bool Item = Regex.IsMatch(LineContent, @"^[^=]+ = .+$");

            if (Item)
            {
                string key = Regex.Match(LineContent, @".*(?= = )").Value;
                string value = Regex.Match(LineContent, @"(?<= = ).*").Value;
                GroupDict.Add(key, value);
            }
            else if (Topic)
            {
                if (GroupDict.Count > 0)
                {
                    ConfigList.Add(Group, new Dictionary<string, string>(GroupDict));
                    GroupDict.Clear();
                }
                Group = Regex.Match(LineContent, @"(?<=\[).*(?=\])").Value;
            }
        }
        if (GroupDict.Count > 0)
        {
            ConfigList.Add(Group, new Dictionary<string, string>(GroupDict));
            GroupDict.Clear();
        }
    }
    public string Get(string KeyGroup, string Key)
    {
        if(ConfigList.TryGetValue(KeyGroup, out Dictionary<string, string> dict) && dict.TryGetValue(Key, out string value))
        {
            return value;
        }
        return "<--" + Key + "-->";
    }
    public bool Has(string KeyGroup, string Key)
    {
        return ConfigList.TryGetValue(KeyGroup, out Dictionary<string, string> dict) && dict.ContainsKey(Key);
    }
    public void Write(string KeyGroup, string Key, string value)
    {
        if (ConfigList[KeyGroup][Key] != value)
        {
            ConfigChange = true;
            ConfigList[KeyGroup][Key] = value;
        }
    }
    public Dictionary<string, string> Get(string KeyGroup)
    {
        return ConfigList[KeyGroup];
    }
    public void Save()
    {
        if (ConfigChange)
        {
            float time = UnityEngine.Time.realtimeSinceStartup;
            string path = UnityEngine.Application.streamingAssetsPath + "/config.ini";
            string[] lines = System.IO.File.ReadAllLines(path);
            string group = "";
            for (int i = 0; i < lines.Length; i++)
            {
                string LineContent = Regex.Replace(lines[i], " ", "");
                bool Topic = Regex.IsMatch(LineContent, @"^\[{1}[^\[\]]+\]{1}$");
                bool Item = Regex.IsMatch(LineContent, @"^[^=]+ ?= ?[^=]+$");
                if (Topic)
                {
                    group = Regex.Match(LineContent, @"(?<=\[).*(?=\])").Value;
                    if (!ConfigList.ContainsKey(group)) group = "";
                }
                else if (Item && group != "")
                {
                    string key = Regex.Match(LineContent, @".*(?==)").Value;
                    string value = Regex.Match(LineContent, @"(?<==).*").Value;
                    if (ConfigList[group].TryGetValue(key, out string s) && s != value)
                    {
                        lines[i] = key + " = " + s;
                        Debug.Log("write key:  " + group + " => " + key + "=" + s);
                    }
                }
            }
            Debug.Log("write complete, use time " + (UnityEngine.Time.realtimeSinceStartup - time) * 1000 + "ms");
            System.IO.File.WriteAllLines(path, lines);
        }
    }
}
public class ConfigReader
{
    private static TextFile Config;
    private static bool IsInit = false;
    public static string Get(string KeyGroup, string Key)
    {
        if (!IsInit) Init();
        return Config.Get(KeyGroup, Key);
    }
    public static void Write(string keyGroup, string key, string value)
    {
        if (!IsInit) Init();
        Config.Write(keyGroup, key, value);
    }
    public static Dictionary<string, string> Get(string KeyGroup)
    {
        if (!IsInit) Init();
        return Config.Get(KeyGroup);
    }
    public static void Save()
    {
        Config.Save();
    }
    private static void Init()
    {
        Config = new TextFile(UnityEngine.Application.streamingAssetsPath + "/config.ini");
        IsInit = true;
    }
}