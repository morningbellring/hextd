using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyAttribute : AttributeManager
{
    [SerializeField] private float Speed = 1;
    protected override void Awake()
    {
        base.Awake();
        AddAttribute("Speed", Speed);
    }
}
