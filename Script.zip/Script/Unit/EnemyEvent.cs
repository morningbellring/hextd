using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyEvent : EventManager
{
    [HideInInspector] public Enemy Enemy;
    protected override void Repal(float force, Vector2 direction)
    {
        if (Enemy.isDead) return;
        float NowSpeed = Enemy.rigidBody.velocity.magnitude;
        float MaxSpeed = Enemy.attribute.Get("Speed");

        Enemy.rigidBody.velocity += direction * force * (NowSpeed < MaxSpeed ? 1 : (MaxSpeed / NowSpeed));
    }
    protected override void Hurt(float value)
    {
        base.Hurt(value);
        Enemy.vision.Flash();
    }
    public override void Die()
    {
        Enemy.Die();
        GameObject.Destroy(this.gameObject, 0.5f);
    }
}
