using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyVision : MonoBehaviour
{
    public SpriteRenderer OutLight;
    public SpriteRenderer InnerLight;

    [HideInInspector] public bool IsDead = false;

    private float NowTime = 0;
    private float NowAlpha = 0;
    private float FlashRate = 0;

    private Color BaseOutLightColor;
    private Color BaseInnerLightColor;

    private Color OutLightColor;
    private Color InnerLightColor;

    public void Flash()
    {
        FlashRate = 1.5f;
    }
    private void Start()
    {
        BaseOutLightColor = OutLight.color;
        OutLightColor = OutLight.color;
        OutLightColor.a = 0;
        OutLight.color = OutLightColor;

        BaseInnerLightColor = InnerLight.color;
        InnerLightColor = InnerLight.color;
        InnerLightColor.a = 0;
        InnerLight.color = InnerLightColor;
    }
    private void Update()
    {
        float deltaTime = Time.deltaTime;
        
        if (NowAlpha >= 1) NowAlpha = 1;
        else NowAlpha += deltaTime;

        OutLightColor.r = BaseOutLightColor.r * (FlashRate + 1);
        OutLightColor.g = BaseOutLightColor.g * (FlashRate + 1);
        OutLightColor.b = BaseOutLightColor.b * (FlashRate + 1);

        InnerLightColor.r = BaseInnerLightColor.r * (FlashRate + 1);
        InnerLightColor.g = BaseInnerLightColor.g * (FlashRate + 1);
        InnerLightColor.b = BaseInnerLightColor.b * (FlashRate + 1);

        if (FlashRate > deltaTime * 10) FlashRate -= deltaTime * 10;
        else FlashRate = 0;

        if (!IsDead)
        {
            NowTime += deltaTime * 6;
            OutLight.transform.localScale = Vector3.one * (1.5f + 0.3f * Mathf.Sin(NowTime));

            OutLightColor.a = (0.5f - 0.3f * Mathf.Sin(NowTime)) * NowAlpha;
            OutLight.color = OutLightColor;

            InnerLightColor.a = NowAlpha;
            InnerLight.color = InnerLightColor;
        }
        else
        {
            OutLight.transform.localScale *= 1 + deltaTime * 5;
            InnerLight.transform.localScale *= 1 - deltaTime;

            OutLightColor.a -= OutLightColor.a <= (deltaTime * 2) ? OutLightColor.a : (deltaTime * 2);
            OutLight.color = OutLightColor;

            InnerLightColor.a -= InnerLightColor.a <= (deltaTime * 2) ? InnerLightColor.a : (deltaTime * 2);
            InnerLight.color = InnerLightColor;
        }
    }
}
