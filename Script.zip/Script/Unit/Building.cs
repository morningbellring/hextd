using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UIElements;

[RequireComponent(typeof(BuildingEvent))]
[RequireComponent(typeof(BuildingAttribute))]
[RequireComponent(typeof(BuildingVision))]
public class Building : MonoBehaviour
{
    private static Color NotCompletedColor = new Color(0.4f, 0.4f, 0.4f);
    private static Color NotConnectedColor = new Color(0.6f, 0.3f, 0.3f);
    private static Color NotPoweredColor = new Color(0.3f, 0.3f, 0.6f);
    private static Color NotAliveColor = new Color(0.4f, 0.4f, 0.4f);

    public static Dictionary<string, Building> allBuildings
    {
        get
        {
            return BuildingList;
        }
    }
    public static float maxRange
    {
        get
        {
            return MaxRange;
        }
    }
    private static Dictionary<string, Building> BuildingList = new Dictionary<string, Building>();
    private static int TotalCount = 0;
    private static float MaxRange = 0;

    protected static Color ProductionColor = new Color(0.7f, 0.9f, 0.7f);

    protected static void RemoveBuilding(Building building)
    {
        BuildingList.Remove(building.Id);

        List<string> affectBuildings = HexagonalMap.RemoveBuilding(building.occupyArea, building.Id);
        foreach(string affectBuilding in affectBuildings)
        {
            BuildingList[affectBuilding].Disconnect();
        }

        Technology.Upgrade(building.Name + "_Amount");
        GlobalMessage.Send("RemoveBuilding", building);
    }
    protected static void BuildBuilding(Building building)
    {
        TotalCount += 1;
        building.Id = TotalCount.ToString();
        BuildingList.Add(building.Id, building);

        List<string> affectBuildings = HexagonalMap.AddBuilding(building.occupyArea, building.Id);
        foreach(string affectBuilding in affectBuildings)
        {
            BuildingList[affectBuilding].Reconnect();
        }
        if(building.transform.position.magnitude > MaxRange)
        {
            MaxRange = building.transform.position.magnitude;
        }

        Technology.Upgrade(building.Name + "_Amount");
        GlobalMessage.Send("BuildNewBuilding", building);
    }
    protected static Building Overlap(Vector2Int position)
    {
        foreach(Building building in BuildingList.Values)
        {
            if (building.occupyArea.Contains(position))
            {
                return building;
            }
        }
        return null;
    }
    protected static List<Building> Overlap(List<Vector2Int> positions)
    {
        List<Building> result = new List<Building>();
        foreach (Building building in BuildingList.Values)
        {
            if (Intersect(building.occupyArea, positions))
            {
                result.Add(building);
            }
        }
        return result;
    }
    protected static bool Intersect(List<Vector2Int> positions01, List<Vector2Int> positions02)
    {
        return positions01.Intersect(positions02).Count() > 0;
    }
    public enum BuildingType
    {
        Core,
        Defense,
        Production,
        Power,
        Research
    }
    public bool isActive
    {
        get
        {
            return IsActive;
        }
    }
    public bool isRemovable
    {
        get
        {
            return IsRemovable;
        }
    }
    public bool isDead
    {
        get
        {
            return IsDead;
        }
    }
    public float buildProgress
    {
        get
        {
            return IsComplete ? 1 : LastBuildProgress;
        }
    }
    public string id { get { return Id; } }
    public float efficiency 
    { 
        get { 
            return IsActive ?
                (NeedPower ? 
                (HasPower ? 
                ResourceManager.GetResourceEffeciency("Power") * CustomEfficiency : 
                0) :
                CustomEfficiency):
                0; 
        } 
    }
    public BuildingAttribute attribute { get { return Attribute; } }
    public BuildingVision vision { get { return Vision; } }
    public EventManager eventManager { get { return Event; } }
    public PannelData pannelData
    {
        get
        {
            return IsComplete ? PannelData : BuildPannel;
        }
    }
    public List<Vector2Int> occupyArea
    {
        get
        {
            List<Vector2Int> result = new List<Vector2Int>();
            result.Add(BuildingPosition);
            foreach(Vector2Int pos in ExtraPos)
            {
                result.Add(BuildingPosition + pos);
            }
            return result;
        }
    }
    public List<Vector2Int> affectArea
    {
        get
        {
            List<Vector2Int> result = new List<Vector2Int>();
            foreach (Vector2Int pos in AffectPos)
            {
                result.Add(BuildingPosition + pos);
            }
            return result;
        }
        set
        {
            AffectPos = value.ToArray();
        }
    }

    public BuildingType Type;
    public Sprite Preview;
    public string Name;
    public bool NeedPower = false;
    public float BuildTime = 10;
    public float BaseHealthRate = 0.11f;
    public float BuildHealthIncreasment = 0.9f;

    public string[] ResourceName = new string[0];
    public float[] ResourceCost = new float[0];

    public Vector2Int[] ExtraPos = new Vector2Int[0];
    [HideInInspector] public Vector2Int BuildingPosition;

    public Color AffectColor = Color.white;
    public Vector2Int[] AffectPos = new Vector2Int[0];

    public string[] TechRequirment = new string[0];
    public int[] TechLevelRequirment = new int[0];

    private string Id = null;
    private float LastBuildProgress = 0;
    private bool IsActive = false;
    private bool IsComplete = false;
    private bool IsConnect = true;
    private bool IsDead = false;
    private bool HasPower = false;
    private BuildingAttribute Attribute;
    private BuildingEvent Event;
    private BuildingVision Vision;
    private Timer BuildTimmer;
    private BuildingProcess Process;
    private TowerControl[] Towers;

    protected PannelData PannelData;
    protected PannelData BuildPannel;
    protected bool IsRemovable = true;
    public float CustomEfficiency = 1;

    public void StartBuild()
    {
        IsConnect = true;
        IsActive = false;

        vision.color = Color.white;
        vision.sortOrder = 0;

        attribute.healthRate = BaseHealthRate;

        PannelData = new PannelData(Preview);
        BuildPannel = new PannelData(Preview);

        BuildTimmer = new Timer(BuildTime, BuildComplete);
        CreateBuildPannel();
        BuildTimmer.Start();

        BuildBuilding(this);

        GameObject processObject =  GameObject.Instantiate(Resources.Load<GameObject>("BuildingProcess"));
        Process = processObject.GetComponent<BuildingProcess>();
        Process.rate = 0;
        Process.followObject = this.gameObject;

        OnBuildingStartBuild();
    }
    public void Replace(Building building)
    {
        Die();
    }
    public void Remove()
    {
        if (IsRemovable)
        {
            float progress = buildProgress;
            float returnRate = 1;
            if(progress >= 1)
            {
                returnRate = attribute.healthRate;
            }else if(progress > 0)
            {
                returnRate = 0.5f;
            }
            for(int i = 0; i < ResourceName.Length; i++)
            {
                ResourceManager.AddResource(ResourceName[i], ResourceCost[i] * returnRate);
            }
            Event.Die();
        }
    }
    public void Die()
    {
        IsDead = true;

        if (Process != null)
        {
            GameObject.Destroy(Process.gameObject);
            Process = null;
        }
        if(BuildTimmer != null)
        {
            BuildTimmer.Cancel();
            BuildTimmer = null;
        }

        if (NeedPower)
        {
            GlobalMessage.SubscribeCancel("AddPowerNode", PowerNodeAdd);
            GlobalMessage.SubscribeCancel("RemovePowerNode", PowerNodeRemove);
        }

        RemoveBuilding(this);
        BuildingStateUpdate();
        OnBuildingDestory();
    }
    public void ShowPreview()
    {
        foreach (TowerControl tower in Towers)
        {
            tower.showRange = true;
        }
        List<Vector2Int> affect = affectArea;
        if(affectArea.Count > 0) TileMap.main.ShowBuildingRange(affect, AffectColor);
    }
    public void HidePreview()
    {
        foreach (TowerControl tower in Towers)
        {
            tower.showRange = false;
        }
        TileMap.main.HideBuildingRange();
    }
    protected float GetEfficiency()
    {
        return efficiency;
    }
    private void PowerNodeAdd(object data)
    {
        if (!HasPower) HasPower = PowerMap.IsPowered(this.occupyArea.ToArray());
        BuildingStateUpdate();
    }
    private void PowerNodeRemove(object data)
    {
        if (HasPower) HasPower = PowerMap.IsPowered(this.occupyArea.ToArray());
        BuildingStateUpdate();
    }
    private void Reconnect()
    {
        IsConnect = true;
        BuildingStateUpdate();
    }
    private void Disconnect()
    {
        IsConnect = false;
        BuildingStateUpdate();
    }
    private void BuildComplete()
    {
        BuildUpdate();

        IsComplete = true;
        BuildPannel.Repaint();
        BuildPannel = null;
        BuildTimmer = null;
        GameObject.Destroy(Process.gameObject);

        Vision.isComplete = true;
        Vision.Flash(Color.white * 2.8f, 0.5f);

        if (NeedPower)
        {
            HasPower = PowerMap.IsPowered(this.occupyArea.ToArray());
            GlobalMessage.Subscribe("AddPowerNode", PowerNodeAdd);
            GlobalMessage.Subscribe("RemovePowerNode", PowerNodeRemove);
        }

        OnBuildingComplete();
        BuildingStateUpdate();
    }
    private void Awake()
    {
        Attribute = this.GetComponent<BuildingAttribute>();
        Vision = this.GetComponent<BuildingVision>();
        Event = this.GetComponent<BuildingEvent>();
        Towers = this.GetComponentsInChildren<TowerControl>();

        vision.Building = this;
    }
    private void Start()
    {
        vision.isComplete = false;
        vision.sortOrder = 10;

        Event.Building = this;
        OnBuildingCreate();
    }
    private void BuildUpdate()
    {
        if (BuildTimmer != null)
        {
            float progress = BuildTimmer.lastRate;
            float deltaProgress = progress - LastBuildProgress;
            LastBuildProgress = progress;

            attribute.healthRate += deltaProgress * BuildHealthIncreasment;
            Process.rate = progress;
        }
    }
    private void FixedUpdate()
    {
        BuildUpdate();
        OnFixedUpdate();
    }
    private void BuildingStateUpdate()
    {
        if (isDead)
        {
            vision.color = NotAliveColor;
        }
        else if (!IsConnect)
        {
            vision.color = NotConnectedColor;
        }
        else if (!IsComplete)
        {
            vision.color = NotCompletedColor;
        }
        else if (NeedPower && !HasPower)
        {
            vision.color = NotPoweredColor;
        }
        else
        {
            vision.color = Color.white;
        }

        if (isDead || !IsComplete || !IsConnect || (NeedPower && !HasPower))
        {
            if (IsActive == false) return;
            IsActive = false;
            foreach (TowerControl tower in Towers)
            {
                tower.enable = false;
            }
            OnBuildingDisable();
        }
        else
        {
            if (IsActive == true) return;
            vision.color = Color.white;
            IsActive = true;
            foreach (TowerControl tower in Towers)
            {
                tower.enable = true;
            }
            OnBuildingEnable();
        }
    }
    protected virtual void CreateBuildPannel()
    {
        BuildPannel.AddHealthBar();
        BuildPannel.AddAttributeDescription("Defence", "Defence");
        BuildPannel.AddBar("ConstructionProgress", Color.white * 0.7f, BuildTimmer.PannelProcess, BuildTimmer.PannelDescription);
    }
    protected virtual void OnFixedUpdate()
    {

    }
    protected virtual void OnBuildingEnable()
    {

    }
    protected virtual void OnBuildingDisable()
    {

    }
    protected virtual void OnBuildingCreate()
    {

    }
    protected virtual void OnBuildingStartBuild()
    {

    }
    protected virtual void OnBuildingComplete()
    {

    }
    protected virtual void OnBuildingDestory()
    {

    }
}
