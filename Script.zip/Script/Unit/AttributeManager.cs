using System;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class AttributeManager : MonoBehaviour
{
    protected class Revision
    {
        public string Name;
        public float Value;
        public float LastTime = -1;
        public Revision() { }
    }

    public float health
    {
        get
        {
            return maxHealth * HealthRate;
        }
        set
        {
            HealthRate = value / maxHealth;
            HealthRate = HealthRate > 1 ? 1 : HealthRate;
        }
    }
    public float healthRate
    {
        get
        {
            return HealthRate;
        }
        set
        {
            if(value > 1)
            {
                HealthRate = 1;
            }else if(value < 0)
            {
                HealthRate = 0;
            }
            else
            {
                HealthRate = value;
            }
        }
    }
    public float maxHealth
    {
        get
        {
            return Get("MaxHealth");
        }
    }
    public float defence
    {
        get
        {
            return Get("Defence");
        }
    }

    public float damage
    {
        get
        {
            return Get("Damage");
        }
    }
    /*public float hurtRate
    {
        get
        {
            return Get("HurtRate");
        }
    }
    public float damageRate
    {
        get
        {
            return Get("DamageRate");
        }
    }*/

    private float HealthRate = 1;
    [SerializeField] private float MaxHealth;
    [SerializeField] private float Damage;
    [SerializeField] private float Defence;

    private Dictionary<string, float> Attributes = new Dictionary<string, float>();
    private Dictionary<string, Dictionary<string, Revision>> RateRevision = new Dictionary<string, Dictionary<string, Revision>>();
    private Dictionary<string, Dictionary<string, Revision>> ValueRevision = new Dictionary<string, Dictionary<string, Revision>>();
    private Dictionary<Revision, string> TimedRevisionAttributeR = new Dictionary<Revision, string>();
    private Dictionary<Revision, string> TimedRevisionAttributeV = new Dictionary<Revision, string>();
    private List<Revision> TimedRevisionR = new List<Revision>();
    private List<Revision> TimedRevisionV = new List<Revision>();

    public float Get(string attributeName)
    {
        if (Attributes.ContainsKey(attributeName))
        {
            float rateRevision = GetRateRevision(attributeName);
            float valueRevision = GetValueRevision(attributeName);
            float result = Attributes[attributeName] * rateRevision + valueRevision;
            return result < Attributes[attributeName] * 0.1f ? Attributes[attributeName] * 0.1f : result;
        }
        else
        {
            Debug.LogError("Not existent attribute '" + attributeName + "' in " + this.gameObject.ToString());
            return 0f;
        }
    }
    public void ChangeBaseValue(string attributeName, float value)
    {
        if (Attributes.ContainsKey(attributeName))
        {
            Attributes[attributeName] = value;
        }
    }
    public float GetBase(string attributeName)
    {
        if (Attributes.ContainsKey(attributeName))
        {
            return Attributes[attributeName];
        }
        else
        {
            Debug.LogError("Not existent attribute '" + attributeName + "' in " + this.gameObject.ToString());
            return 0f;
        }
    }
    public string ReviseRate(string attributeName, string revisionName, float value, float lastTime = -1)
    {
        if (RateRevision.ContainsKey(attributeName))
        {
            if (RateRevision[attributeName].ContainsKey(revisionName))
            {
                RemoveRateRevision(attributeName, revisionName);
            }
            Revision target = new Revision();
            target.Value = value;
            target.LastTime = lastTime;
            target.Name = revisionName;
            RateRevision[attributeName].Add(revisionName, target);
            if (lastTime > 0)
            {
                TimedRevisionR.Add(target);
                TimedRevisionAttributeR.Add(target, attributeName);
            }
        }
        else
        {
            Debug.LogError("Not existent attribute '" + attributeName + "' in " + this.gameObject.ToString());
        }
        return revisionName;
    }
    public string ReviseValue(string attributeName, string revisionName, float value, float lastTime = -1)
    {
        if (ValueRevision.ContainsKey(attributeName))
        {
            if(ValueRevision[attributeName].ContainsKey(revisionName))
            {
                RemoveValueRevision(attributeName, revisionName);
            }
            Revision target = new Revision();
            target.Value = value;
            target.LastTime = lastTime;
            target.Name = revisionName;
            ValueRevision[attributeName].Add(revisionName, target);
            if(lastTime > 0)
            {
                TimedRevisionV.Add(target);
                TimedRevisionAttributeV.Add(target, attributeName);
            }
        }
        else
        {
            Debug.LogError("Not existent attribute '" + attributeName + "' in " + this.gameObject.ToString());
        }
        return revisionName;
    }
    public void RemoveRateRevision(string attributeName, string revisionName)
    {
        if (RateRevision.ContainsKey(attributeName) && RateRevision[attributeName].ContainsKey(revisionName))
        {
            Revision target = RateRevision[attributeName][revisionName];
            RateRevision[attributeName].Remove(revisionName);
            if (TimedRevisionAttributeR.ContainsKey(target))
            {
                TimedRevisionAttributeR.Remove(target);
                TimedRevisionR.Remove(target);
            }
        }
    }
    public void RemoveValueRevision(string attributeName, string revisionName)
    {
        if (ValueRevision.ContainsKey(attributeName) && ValueRevision[attributeName].ContainsKey(revisionName))
        {
            Revision target = ValueRevision[attributeName][revisionName];
            ValueRevision[attributeName].Remove(revisionName);
            if (TimedRevisionAttributeV.ContainsKey(target))
            {
                TimedRevisionAttributeV.Remove(target);
                TimedRevisionV.Remove(target);
            }
        }
    }
    public float ApplyRevision(string attributeName, float value)
    {
        float rateRevision = GetRateRevision(attributeName);
        float valueRevision = GetValueRevision(attributeName);
        return value * rateRevision + value;
    }
    protected virtual void Awake()
    {
        AddAttribute("MaxHealth", MaxHealth);
        AddAttribute("Defence", Defence);
        AddAttribute("Damage", Damage);
        AddAttribute("HurtRate", 1);
        AddAttribute("DamageRate", 1);
    }
    protected void AddAttribute(string attributeName, float value)
    {
        Attributes.Add(attributeName, value);
        RateRevision.Add(attributeName, new Dictionary<string, Revision>());
        ValueRevision.Add(attributeName, new Dictionary<string, Revision>());
    }
    protected float GetRateRevision(string attributeName)
    {
        if (RateRevision.ContainsKey(attributeName))
        {
            float increaseResult = 1;
            float decreaseResult = 1;
            foreach(Revision r in RateRevision[attributeName].Values)
            {
                if (r.Value > 0) increaseResult += r.Value;
                else decreaseResult *= 1 + r.Value;
            }
            return increaseResult * decreaseResult;
        }
        else return 1;
    }
    protected float GetValueRevision(string attributeName)
    {
        if (ValueRevision.ContainsKey(attributeName))
        {
            float result = 0;
            foreach (Revision r in ValueRevision[attributeName].Values)
            {
                result += r.Value;
            }
            return result;
        }
        else return 0;
    }
    private void FixedUpdate()
    {
        for(int i = TimedRevisionR.Count - 1; i >= 0; i--)
        {
            Revision r = TimedRevisionR[i];
            r.LastTime -= UnityEngine.Time.fixedDeltaTime;
            if(r.LastTime <= 0)
            {
                TimedRevisionR.RemoveAt(i);
                RateRevision[TimedRevisionAttributeR[r]].Remove(r.Name);
                TimedRevisionAttributeR.Remove(r);
            }
        }
        for (int i = TimedRevisionV.Count - 1; i >= 0; i--)
        {
            Revision r = TimedRevisionV[i];
            r.LastTime -= UnityEngine.Time.fixedDeltaTime;
            if (r.LastTime <= 0)
            {
                TimedRevisionV.RemoveAt(i);
                ValueRevision[TimedRevisionAttributeV[r]].Remove(r.Name);
                TimedRevisionAttributeV.Remove(r);
            }
        }
    }
}
