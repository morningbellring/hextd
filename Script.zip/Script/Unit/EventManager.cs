using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EventManager : MonoBehaviour
{
    [HideInInspector] public AttributeManager Attribute;
    protected virtual void Awake()
    {
        Attribute = this.GetComponent<AttributeManager>();
    }
    protected virtual void Hurt(float value)
    {
        float defense = Attribute.defence;
        value *= defense / (defense + 20);
        value = Attribute.ApplyRevision("HurtRate", value);
        value = value < 1 ? 1 : value;

        Attribute.health -= value;
        if(Attribute.health <= 0)
        {
            Die();
        }
    }
    protected virtual void Heal(float value)
    {
        if(Attribute.health != Attribute.maxHealth)
        {
            Attribute.health += value;
        }
    }
    protected virtual void Repal(float force, Vector2 direction)
    {

    }
    public virtual void Heal(EventManager target, float value)
    {
        target.Heal(value);
    }
    public virtual void Damage(EventManager target, float rate)
    {
        float value = Attribute.ApplyRevision("DamageRate", rate * Attribute.damage);
        target.Hurt(value);
    }
    public virtual void Repal(EventManager target, float force, Vector2 direction)
    {
        target.Repal(force, direction);
    }
    public virtual void Die()
    {
        GameObject.Destroy(this.gameObject, 2);
    }
}
