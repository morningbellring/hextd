using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    public static int NowID = 0;
    public static Dictionary<int, Enemy> EnemyList = new Dictionary<int, Enemy>();

    public static float MinSize = 0.1f;
    public static float MaxSize = 0.2f;

    private int Id;
    private bool IsDead = false;

    [SerializeField] private EnemyEvent Event;
    [SerializeField] private EnemyAttribute Attribute;
    [SerializeField] private EnemyVision Vision;
    [SerializeField] private Rigidbody2D RigidBody;
    [SerializeField] private Collider2D Collider;

    private Building Target;
    private Vector2 TargetPos;
    private List<Vector2Int> TargetMapPos;
    private int ChooseTargetInterval = 0;

    public float GoldRate = 0.01f;

    public bool isDead { get { return IsDead; } }
    public EnemyEvent eventManager{ get { return Event; } }
    public EnemyAttribute attribute { get { return Attribute; } }
    public EnemyVision vision { get { return Vision; } }
    public Rigidbody2D rigidBody { get { return RigidBody; } }

    public void Start()
    {
        NowID++;
        Id = NowID;
        EnemyList.Add(NowID, this);

        Event.Enemy = this;
        Collider.enabled = true;
    }
    public void Hit(Building building)
    {
        GoldRate = 0;
        this.eventManager.Damage(building.eventManager, 1);
        this.eventManager.Die();
    }
    public void Die()
    {
        ResourceManager.AddResource("Gold", attribute.maxHealth * GoldRate);
        IsDead = true;
        Collider.enabled = false;
        RigidBody.velocity = Vector2.zero;
        EnemyList.Remove(Id);
        Vision.IsDead = true;
    }
    private void FixedUpdate()
    {
        if (IsDead) return;

        if (Target != null) TargetPos = Target.transform.position;
        else if (Vector2.Distance(this.transform.position, TargetPos) <= 1) ChooseTarget();

        ChooseTargetInterval--;
        if (ChooseTargetInterval <= 0)
        {
            ChooseTarget();
        }

        Vector2 nowV = RigidBody.velocity;
        float nowSpeed = nowV.magnitude;
        float maxSpeed = Attribute.Get("Speed");
        if(nowSpeed <= maxSpeed)
        {
            nowV += (TargetPos - (Vector2)this.transform.position).normalized * Time.fixedDeltaTime * 12;
            if(nowV.magnitude > maxSpeed)
            {
                nowV = nowV.normalized * maxSpeed;
            }
        }
        else
        {
            nowV *= (nowSpeed - Time.fixedDeltaTime * 12) / nowSpeed;
        }
        
        RigidBody.velocity = nowV;

        if (TargetMapPos.Contains(TileMap.main.GetMapPos(this.transform.position)))
        {
            Hit(Target);
        }
    }
    private void ChooseTarget()
    {
        ChooseTargetInterval = 25;
        float minDistance = 99999;
        foreach (Building b in Building.allBuildings.Values)
        {
            float distance = Vector2.Distance(b.transform.position, this.transform.position);
            if (distance < minDistance)
            {
                Target = b;
                minDistance = distance;
            }
        }
        TargetPos = Target.transform.position;
        TargetMapPos = Target.occupyArea;
    }
}
