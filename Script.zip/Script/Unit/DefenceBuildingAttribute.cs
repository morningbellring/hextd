using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DefenceBuildingAttribute : BuildingAttribute
{
    [SerializeField] private float AttackSpeed = 1;
    [SerializeField] private float WeaponRange = 6;
    protected override void Awake()
    {
        base.Awake();
        AddAttribute("AttackSpeed", AttackSpeed);
        AddAttribute("WeaponRange", WeaponRange);
    }
}
