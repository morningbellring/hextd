using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BuildingEvent : EventManager
{
    [HideInInspector] public Building Building;
    protected override void Heal(float value)
    {
        if(Building.attribute.healthRate < 1) Building.vision.Flash(BuildingVision.HealColor, 0.5f);
        base.Heal(value);
    }
    protected override void Hurt(float value)
    {
        Building.vision.Flash(BuildingVision.HurtColor, 0.3f);
        base.Hurt(value);
    }

    public override void Die()
    {
        base.Die();
        Debug.Log("Building:" + Building.ToString());
        Debug.Log("Vision:" + Building.vision);
        Building.vision.Die();
        Building.Die();
    }
}
