using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SkillManager : MonoBehaviour
{
    private void Start()
    {
        
    }
    private void Update()
    {
        
    }
}
public class Skill
{
    public string Name;
}
