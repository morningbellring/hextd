using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BuildingVision : MonoBehaviour
{
    public static Color HurtColor = new Color(1f, 0.3f, 0.3f, 1);
    public static Color HealColor = new Color(0.3f, 1f, 0.3f, 1);

    private static MaterialPropertyBlock Prop;

    [SerializeField] private Renderer[] Renderers = new Renderer[1];

    private bool Breathing = false;
    private float HighLightTime = 0;
    private float ScaleTime = 0;
    private float DeathRate = 0;

    private float FlashTime;
    private float NowFlashTime;

    private bool IsComplete;
    private bool IsDead = false;
    private int AddSortOrder = 0;

    [HideInInspector] public Building Building;

    public bool isComplete
    {
        set
        {
            IsComplete = value;
            foreach (Renderer r in Renderers)
            {
                r.GetPropertyBlock(Prop);
                Prop.SetInt("_IsComplete", value ? 1 : 0);
                Prop.SetFloat("_NoiseStrength", IsComplete ? (1 - Building.attribute.healthRate) : 1);
                r.SetPropertyBlock(Prop);
            }
        }
    }
    public Color color
    {
        set
        {
            foreach (Renderer r in Renderers)
            {
                (r as SpriteRenderer).color = value;
            }
        }
    }
    public int sortOrder
    {
        set
        {
            int layerChange = value - AddSortOrder;
            AddSortOrder = value;
            foreach (Renderer r in Renderers)
            {
                (r as SpriteRenderer).sortingOrder += layerChange;
            }
        }
    }
    public void Die()
    {
        IsDead = true;
    }
    public void Flash(Color flashColor, float flashTime)
    {
        if (Breathing) return;
        foreach (Renderer r in Renderers)
        {
            r.GetPropertyBlock(Prop);
            Prop.SetColor("_MixColor", flashColor);
            Prop.SetFloat("_MixRate", 1);
            r.SetPropertyBlock(Prop);
        }
        FlashTime = flashTime;
        NowFlashTime = flashTime;
    }
    public void StartBreathe(Color highLightColor)
    {
        Breathing = true;
        HighLightTime = 0;
        ScaleTime = Mathf.PI;
        foreach (Renderer r in Renderers)
        {
            r.GetPropertyBlock(Prop);
            Prop.SetColor("_MixColor", highLightColor);
            Prop.SetFloat("_MixRate", 1);
            r.SetPropertyBlock(Prop);
        }
        this.transform.localScale = Vector3.one;
    }
    public void StopBreathe()
    {
        Breathing = false;
        foreach (Renderer r in Renderers)
        {
            r.GetPropertyBlock(Prop);
            Prop.SetFloat("_MixRate", 0);
            r.SetPropertyBlock(Prop);
        }
        this.transform.localScale = Vector3.one;
    }
    private void Awake()
    {
        if (Prop == null) Prop = new MaterialPropertyBlock();
    }
    private void Update()
    {
        if (NowFlashTime > 0)
        {
            NowFlashTime -= Time.unscaledDeltaTime;
            NowFlashTime = NowFlashTime < 0 ? 0 : NowFlashTime;
            if (!Breathing)
            {
                foreach (Renderer r in Renderers)
                {
                    r.GetPropertyBlock(Prop);
                    Prop.SetFloat("_MixRate", NowFlashTime / FlashTime);
                    r.SetPropertyBlock(Prop);
                }
            }
        }
        if (Breathing)
        {
            HighLightTime += Time.unscaledDeltaTime * 8;
            float mixRate = (Mathf.Cos(HighLightTime) + 1) / 2;
            foreach (Renderer r in Renderers)
            {
                r.GetPropertyBlock(Prop);
                Prop.SetFloat("_MixRate", mixRate);
                r.SetPropertyBlock(Prop);
            }

            if (ScaleTime > 0)
            {
                ScaleTime -= Time.unscaledDeltaTime * 16;
                ScaleTime = ScaleTime < 0 ? 0 : ScaleTime;
                this.transform.localScale = Vector3.one * (1 + Mathf.Sin(ScaleTime) * 0.2f);
            }
        }
        foreach (Renderer r in Renderers)
        {
            r.GetPropertyBlock(Prop);
            Prop.SetFloat("_NoiseStrength", IsComplete ? (1 - Building.attribute.healthRate) : 1);
            r.SetPropertyBlock(Prop);
        }
        if (IsDead)
        {
            foreach (Renderer r in Renderers)
            {
                DeathRate += Time.unscaledDeltaTime;
                r.GetPropertyBlock(Prop);
                Prop.SetFloat("_DissRate", DeathRate);
                r.SetPropertyBlock(Prop);
            }
        }
    }
}
