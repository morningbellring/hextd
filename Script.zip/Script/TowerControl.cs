using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TowerControl : MonoBehaviour
{
    public bool enable
    {
        set
        {
            Enable = value;
        }
    }
    public bool showRange
    {
        set
        {
            InitRange();
            if (RangeObject.activeSelf != value)
            {
                RangeObject.SetActive(value);
                RangeObject.transform.localScale = Vector3.one * range;
            }
        }
    }
    public float weaponRange
    {
        get
        {
            return range;
        }
    }
    private bool Enable = false;

    public float speed_rotate;
    public GunControl gun;
    public Building Building;
    public float range_rate;

    protected float range;
    protected Collider2D aim_target; //Ŀ����ײ��
    protected Vector2 position_target; //Ŀ������
    protected int stage_rotate; //��ת�׶�

    //������
    protected float attack_speed;
    protected float attack_speed_copy;
    //�Ƿ�ת�����ʽǶ�
    protected int rotate_ready;

    //Ѱ�м��
    protected int find_interval;

    private GameObject RangeObject;
    private LayerMask EnemyLayer;

    private void InitRange()
    {
        if(RangeObject == null)
        {
            RangeObject = GameObject.Instantiate(Resources.Load<GameObject>("WeaponRange"));
            RangeObject.transform.SetParent(transform);
            RangeObject.transform.localPosition = Vector3.zero;
            RangeObject.SetActive(false);
        }
    }
    private void Start()
    {
        attack_speed_copy = 0;
        find_interval = 0;

        gun.Building = Building;
        EnemyLayer = LayerMask.GetMask(new string[] { "Enemy" });
        InitRange();
    }

    private void Update()
    {
        range = Building.attribute.Get("WeaponRange") * range_rate;
        attack_speed = Building.attribute.Get("AttackSpeed") * Building.efficiency;

        if (!Enable)
        {
            return;
        }
        
        move_rotate();
        fire_control();
        get_target();

    }
    private void FixedUpdate()
    {
        if (RangeObject.activeSelf) RangeObject.transform.localScale = Vector3.one * range;

        //ÿ15Ѱ��
        if (find_interval >= 15)
        {
            find_target();
            find_interval = 0;
        }
        find_interval += 1;
    }


    //������̨��Ŀ��н�



    //��̨ת�򶯻�
    public void move_round()
    {
        Vector2 pivot = transform.position;
        Vector2 target = position_target - pivot;
        Vector2 tower = new Vector2(Mathf.Cos((transform.eulerAngles.z + 90) * Mathf.PI / 180), Mathf.Sin((transform.eulerAngles.z + 90) * Mathf.PI / 180));
        float angle = Vector2.SignedAngle(target, tower);
        float rotation = speed_rotate * Time.deltaTime;

        rotate_ready = 0;
        if (angle < -rotation)
        {
            transform.eulerAngles += new Vector3(0, 0, rotation);
        }
        else if (angle > rotation)
        {
            transform.eulerAngles -= new Vector3(0, 0, rotation);
        }
        else
        {
            Vector2 x = new Vector2(1, 0);
            float angle_target = Vector2.SignedAngle(x, target);
            Vector3 temp = new Vector3(0, 0, angle_target - 90);
            rotate_ready = 1;
            transform.eulerAngles = temp;
        }

        /*if (Mathf.Abs(angle) <= 5)
        {
            Vector2 x = new Vector2(1, 0);
            float angle_target = Vector2.SignedAngle(x, target);
            Vector3 temp = new Vector3(0, 0, angle_target - 90);
            rotate_ready = 1;
            transform.eulerAngles = temp;

        }
        else { rotate_ready = 0; }*/
    }

    //ת����
    public void move_rotate()
    {
        if (stage_rotate == 1) { move_round(); }

    }

            
    public void stop_rotate()
    {
        stage_rotate = 0;
    }

    public void fire_control()
    {

        attack_speed_copy += Time.deltaTime;


        if (rotate_ready == 1 && attack_speed_copy >= 1/attack_speed && aim_target != null)
        {

            gun.Fire(aim_target);
            attack_speed_copy = 0;
        }

    }

    //���ҵ����㷨
    public void find_target()
    {
        if (find_interval >= 15)
        {
            Collider2D[] enemy_list = Physics2D.OverlapCircleAll(this.transform.position, range, EnemyLayer);
            if (enemy_list.Length != 0)
            {
                float highest_point = -1000000000;
                Collider2D enemy = enemy_list[0];
                foreach (Collider2D i in enemy_list)
                {
                    //Debug.Log(i.ToString() + ": " + i.transform.position);

                    Vector2 pivot = this.transform.position;
                    Vector2 tar = i.transform.position;
                    Vector2 target = tar - pivot;
                    Vector2 tower = new Vector2(Mathf.Cos((transform.eulerAngles.z + 90) * Mathf.PI / 180), 
                                                Mathf.Sin((transform.eulerAngles.z + 90) * Mathf.PI / 180));
                    float angle = Vector2.Angle(target, tower); //����Ƕ�


                    float time = angle / speed_rotate;
                    float distance = Vector2.Distance(i.transform.position, transform.position);
                    float point = - distance - time; //Ŀ��Ȩ��

                    if (point >= highest_point)
                    {
                        highest_point = point;
                        enemy = i;
                    }

                }
                aim_target = enemy;

                find_interval = 0;
            }
            else { aim_target = null; }

        }
    }

    //��ȡĿ��transform ����
    public void get_target()
    {
        if(aim_target== null)
        {
            stop_rotate();
            find_target();
        }
        else
        {
            Transform aim = aim_target.transform;
            stage_rotate = 1;
            position_target = aim.position;
        }
        
    }  
}
